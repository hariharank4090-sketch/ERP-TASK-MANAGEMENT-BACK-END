// controllers/authorization/appMenu.controller.ts
import { Request, Response } from 'express';
import { QueryTypes, Sequelize } from 'sequelize';
import {
    getDefaultConnection,
    getUserDatabaseConnectionFromToken,
} from '../../../config/database.config';

// ─── Types ────────────────────────────────────────────────────────────────────

interface MenuRow {
    id: number;
    name: string;
    menu_type: number;
    parent_id: number | null;
    url: string;
    tUrl: string;
    rUrl: string;
    actionType: string;
    display_order: number;
    is_active: number;
    Read_Rights: number;
    Add_Rights: number;
    Edit_Rights: number;
    Delete_Rights: number;
    Print_Rights: number;
    ParantData?: Record<string, unknown>;
    [key: string]: unknown;
}

interface MenuWithChildren extends MenuRow {
    SubMenu?: MenuWithChildren[];
    ChildMenu?: MenuWithChildren[];
    SubRoutes?: MenuWithChildren[];
}

interface ModifyUserRightsBody {
    MenuId: number;
    User: number;
    ReadRights: number;
    AddRights: number;
    EditRights: number;
    DeleteRights: number;
    PrintRights: number;
}

interface ModifyUserTypeRightsBody {
    MenuId: number;
    UserType: number;
    ReadRights: number;
    AddRights: number;
    EditRights: number;
    DeleteRights: number;
    PrintRights: number;
}

interface CreateMenuBody {
    name: string;
    menu_type: number;
    parent_id?: number | null;
    url: string;
    tUrl: string;
    rUrl: string;
    display_order: number;
    is_active?: number;
    actionType?: string;
}

interface UpdateMenuBody extends CreateMenuBody {
    id: number;
}

interface UserInfo {
    userTypeId: number;
    globalUserId: number;
    localUserId: number;
}



// ─── Response helpers ────────────────────────────────────────────────────────

const dataFound = (
    res: Response,
    data: unknown,
    message = 'Data Found',
    others: Record<string, unknown> = {},
): void => {
    res.status(200).json({ status: true, message, data, ...others });
};

const failed = (res: Response, message = 'No data found'): void => {
    res.status(200).json({ status: false, message, data: [] });
};

const invalidInput = (res: Response, message = 'Invalid input'): void => {
    res.status(400).json({ status: false, message, data: null });
};

const success = (res: Response, message = 'Success'): void => {
    res.status(200).json({ status: true, message });
};

const servError = (e: unknown, res: Response): void => {
    console.error(e);
    res.status(500).json({ status: false, message: 'Server error', error: String(e) });
};

// ─── Utility helpers ──────────────────────────────────────────────────────────

const isEqualNumber = (a: unknown, b: unknown): boolean =>
    Number(a) === Number(b);

const isValidNumber = (v: unknown): boolean =>
    v !== null && v !== undefined && v !== '' && !isNaN(Number(v));

const stringCompare = (a: unknown, b: unknown): boolean =>
    String(a).toLowerCase().trim() === String(b).toLowerCase().trim();

// ─── Token extractor ──────────────────────────────────────────────────────────

const extractToken = (req: Request): string | null => {
    const header = req.headers.authorization;
    if (header?.startsWith('Bearer ')) return header.substring(7).trim();
    return header ?? null;
};

// ─── Route-tree builder ───────────────────────────────────────────────────────

const buildRoutesTree = (
    routes: MenuRow[],
    parentId: number | null = null,
): MenuWithChildren[] => {
    return routes
        .filter(r => r.parent_id === parentId)
        .map(r => ({
            ...r,
            SubRoutes: buildRoutesTree(routes, r.id),
        }));
};

// ─── Menu structure builder ───────────────────────────────────────────────────

const buildMenuStructure = (rows: MenuRow[]): MenuWithChildren[] => {
    const mainMenu = rows.filter(m => isEqualNumber(m.menu_type, 1)).sort((a, b) => a.display_order - b.display_order);
    const subMenu = rows.filter(m => isEqualNumber(m.menu_type, 2)).sort((a, b) => a.display_order - b.display_order);
    const childMenu = rows.filter(m => isEqualNumber(m.menu_type, 3)).sort((a, b) => a.display_order - b.display_order);
    const subRoutings = rows
        .filter(m => isEqualNumber(m.menu_type, 0))
        .sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));

    return mainMenu.map(main => ({
        ...main,
        SubMenu: subMenu
            .filter(sub => isEqualNumber(sub.parent_id, main.id))
            .map(sub => ({
                ...sub,
                ChildMenu: childMenu
                    .filter(child => isEqualNumber(child.parent_id, sub.id))
                    .map(child => ({
                        ...child,
                        SubRoutes: buildRoutesTree(subRoutings, child.id),
                    })),
                SubRoutes: buildRoutesTree(subRoutings, sub.id),
            })),
        SubRoutes: buildRoutesTree(subRoutings, main.id),
    }));
};

// ─── Helper: get company DB connection (for rights and menu tables) ────────────────────

const getCompanyDB = async (token: string | null): Promise<Sequelize> => {
    if (!token) return getDefaultConnection();
    try {
        return await getUserDatabaseConnectionFromToken(token);
    } catch {
        return getDefaultConnection();
    }
};

// ─── Helper: get user info from token (from default database) ──────────────

const getUserInfoFromToken = async (token: string | null): Promise<UserInfo | null> => {
    if (!token) return null;
    try {
        const defaultDB = getDefaultConnection();
        const rows = await defaultDB.query(
            `SELECT UserTypeId, Global_User_ID, Local_User_ID 
             FROM tbl_Users 
             WHERE Autheticate_Id = :token AND UDel_Flag = 0`,
            { replacements: { token }, type: QueryTypes.SELECT },
        ) as any[];

        if (rows.length > 0) {
            return {
                userTypeId: Number(rows[0].UserTypeId),
                globalUserId: Number(rows[0].Global_User_ID),
                localUserId: Number(rows[0].Local_User_ID)
            };
        }
        return null;
    } catch (error) {
        console.error('Error getting user info:', error);
        return null;
    }
};

// ─── getUserMenuRights ────────────────────────────────────────────────────────

const getUserMenuRights = async (token: string | null): Promise<MenuRow[] | false> => {
    try {
        const [userInfo, companyDB] = await Promise.all([
            getUserInfoFromToken(token),
            getCompanyDB(token),
        ]);

        // Admin / management → full rights
        if (userInfo && (isEqualNumber(userInfo.userTypeId, 0) || isEqualNumber(userInfo.userTypeId, 1))) {
            const rows = await companyDB.query(
                `SELECT *,
                    1 AS Read_Rights,
                    1 AS Add_Rights,
                    1 AS Edit_Rights,
                    1 AS Delete_Rights,
                    1 AS Print_Rights
                 FROM tbl_AppMenu`,
                { type: QueryTypes.SELECT }
            ) as MenuRow[];
            return rows;
        }

        // Use Local_User_ID for rights query
        const localUserId = userInfo ? userInfo.localUserId : null;

        // Run menu and rights queries in parallel
        const [menus, userRights, userTypeRights] = await Promise.all([
            companyDB.query(
                `SELECT * FROM tbl_AppMenu`,
                { type: QueryTypes.SELECT }
            ) as Promise<MenuRow[]>,

            localUserId ? companyDB.query(
                `SELECT
                    ur.MenuId,
                    ur.Read_Rights,
                    ur.Add_Rights,
                    ur.Edit_Rights,
                    ur.Delete_Rights,
                    ur.Print_Rights
                 FROM tbl_AppMenu_UserRights ur
                 WHERE ur.UserId = :localUserId`,
                { replacements: { localUserId }, type: QueryTypes.SELECT }
            ) as Promise<any[]> : Promise.resolve([]),

            companyDB.query(
                `SELECT
                    utr.MenuId,
                    utr.Read_Rights,
                    utr.Add_Rights,
                    utr.Edit_Rights,
                    utr.Delete_Rights,
                    utr.Print_Rights
                 FROM tbl_AppMenu_UserTypeRights utr
                 WHERE utr.UserTypeId = :userTypeId`,
                { replacements: { userTypeId: userInfo?.userTypeId || 0 }, type: QueryTypes.SELECT }
            ) as Promise<any[]>
        ]);

        // Build lookup maps
        const urMap = new Map(userRights.map(r => [r.MenuId, r]));
        const utrMap = new Map(userTypeRights.map(r => [r.MenuId, r]));

        // Merge rights
        const rows: MenuRow[] = menus.map(m => {
            const ur = urMap.get(m.id);
            const utr = utrMap.get(m.id);
            return {
                ...m,
                Read_Rights: ur?.Read_Rights ?? utr?.Read_Rights ?? 0,
                Add_Rights: ur?.Add_Rights ?? utr?.Add_Rights ?? 0,
                Edit_Rights: ur?.Edit_Rights ?? utr?.Edit_Rights ?? 0,
                Delete_Rights: ur?.Delete_Rights ?? utr?.Delete_Rights ?? 0,
                Print_Rights: ur?.Print_Rights ?? utr?.Print_Rights ?? 0,
            };
        });

        return rows;
    } catch (e) {
        console.error('Error in getUserMenuRights:', e);
        return false;
    }
};

// ─── getUserRightsForSpecificUser ─────────────────────────────────────────────

const getUserRightsForSpecificUser = async (targetUserId: number, token: string | null): Promise<MenuRow[] | false> => {
    try {
        const currentUserInfo = await getUserInfoFromToken(token);
        const companyDB = await getCompanyDB(token);

        const menus = await companyDB.query(
            `SELECT * FROM tbl_AppMenu`,
            { type: QueryTypes.SELECT }
        ) as MenuRow[];

        const isAdmin = currentUserInfo && (isEqualNumber(currentUserInfo.userTypeId, 0) || isEqualNumber(currentUserInfo.userTypeId, 1));

        if (isAdmin) {
            const rows: MenuRow[] = menus.map(m => ({
                ...m,
                Read_Rights: 1,
                Add_Rights: 1,
                Edit_Rights: 1,
                Delete_Rights: 1,
                Print_Rights: 1,
            }));
            return rows;
        }

        const userRights = await companyDB.query(
            `SELECT
                ur.MenuId,
                ur.Read_Rights,
                ur.Add_Rights,
                ur.Edit_Rights,
                ur.Delete_Rights,
                ur.Print_Rights
             FROM tbl_AppMenu_UserRights ur
             WHERE ur.UserId = :targetUserId`,
            { replacements: { targetUserId }, type: QueryTypes.SELECT },
        ) as any[];

        const defaultDB = getDefaultConnection();
        const targetUserInfo = await defaultDB.query(
            `SELECT UserTypeId, Local_User_ID FROM tbl_Users WHERE Global_User_ID = :targetUserId AND UDel_Flag = 0`,
            { replacements: { targetUserId }, type: QueryTypes.SELECT },
        ) as any[];

        let userTypeRights: Array<any> = [];

        if (targetUserInfo.length > 0) {
            const targetUserTypeId = targetUserInfo[0].UserTypeId;
            userTypeRights = await companyDB.query(
                `SELECT
                    utr.MenuId,
                    utr.Read_Rights,
                    utr.Add_Rights,
                    utr.Edit_Rights,
                    utr.Delete_Rights,
                    utr.Print_Rights
                 FROM tbl_AppMenu_UserTypeRights utr
                 WHERE utr.UserTypeId = :targetUserTypeId`,
                { replacements: { targetUserTypeId }, type: QueryTypes.SELECT },
            ) as any[];
        }

        const urMap = new Map(userRights.map(r => [r.MenuId, r]));
        const utrMap = new Map(userTypeRights.map(r => [r.MenuId, r]));

        const rows: MenuRow[] = menus.map(m => {
            const ur = urMap.get(m.id);
            const utr = utrMap.get(m.id);
            return {
                ...m,
                Read_Rights: ur?.Read_Rights ?? utr?.Read_Rights ?? 0,
                Add_Rights: ur?.Add_Rights ?? utr?.Add_Rights ?? 0,
                Edit_Rights: ur?.Edit_Rights ?? utr?.Edit_Rights ?? 0,
                Delete_Rights: ur?.Delete_Rights ?? utr?.Delete_Rights ?? 0,
                Print_Rights: ur?.Print_Rights ?? utr?.Print_Rights ?? 0,
            };
        });

        return rows;
    } catch (e) {
        console.error('Error in getUserRightsForSpecificUser:', e);
        return false;
    }
};

const getUserBasedRights = async (userId: number, token: string | null): Promise<MenuRow[] | false> => {
    try {
        const companyDB = await getCompanyDB(token);

        const menus = await companyDB.query(
            `SELECT * FROM tbl_AppMenu`,
            { type: QueryTypes.SELECT }
        ) as MenuRow[];

        const defaultDB = getDefaultConnection();
        let targetUserInfo: any[] = [];

        try {
            targetUserInfo = await companyDB.query(
                `SELECT UserTypeId, Local_User_ID, Global_User_ID FROM tbl_Users WHERE (Global_User_ID = :userId OR Local_User_ID = :userId OR UserId = :userId) AND UDel_Flag = 0`,
                { replacements: { userId }, type: QueryTypes.SELECT },
            ) as any[];
        } catch {
            targetUserInfo = [];
        }

        if (!targetUserInfo.length) {
            try {
                targetUserInfo = await defaultDB.query(
                    `SELECT UserTypeId, Local_User_ID, Global_User_ID FROM tbl_Users WHERE (Global_User_ID = :userId OR Local_User_ID = :userId OR UserId = :userId) AND UDel_Flag = 0`,
                    { replacements: { userId }, type: QueryTypes.SELECT },
                ) as any[];
            } catch {
                targetUserInfo = [];
            }
        }

        const userObj = targetUserInfo[0] || null;
        const userTypeId = userObj ? Number(userObj.UserTypeId) : null;
        const localUserId = userObj?.Local_User_ID != null ? Number(userObj.Local_User_ID) : userId;
        const globalUserId = userObj?.Global_User_ID != null ? Number(userObj.Global_User_ID) : userId;

        if (userTypeId !== null && (isEqualNumber(userTypeId, 0) || isEqualNumber(userTypeId, 1))) {
            const rows: MenuRow[] = menus.map(m => ({
                ...m,
                Read_Rights: 1,
                Add_Rights: 1,
                Edit_Rights: 1,
                Delete_Rights: 1,
                Print_Rights: 1,
            }));
            return rows;
        }

        const [userRights, userTypeRights] = await Promise.all([
            companyDB.query(
                `SELECT MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights
                 FROM tbl_AppMenu_UserRights
                 WHERE UserId = :userId OR UserId = :localUserId OR UserId = :globalUserId`,
                { replacements: { userId, localUserId, globalUserId }, type: QueryTypes.SELECT },
            ) as Promise<any[]>,
            userTypeId != null ? companyDB.query(
                `SELECT MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights
                 FROM tbl_AppMenu_UserTypeRights
                 WHERE UserTypeId = :userTypeId`,
                { replacements: { userTypeId }, type: QueryTypes.SELECT },
            ) as Promise<any[]> : Promise.resolve([])
        ]);

        const urMap = new Map(userRights.map(r => [r.MenuId, r]));
        const utrMap = new Map(userTypeRights.map(r => [r.MenuId, r]));

        const rows: MenuRow[] = menus.map(m => {
            const ur = urMap.get(m.id);
            const utr = utrMap.get(m.id);
            return {
                ...m,
                Read_Rights: ur?.Read_Rights ?? utr?.Read_Rights ?? 0,
                Add_Rights: ur?.Add_Rights ?? utr?.Add_Rights ?? 0,
                Edit_Rights: ur?.Edit_Rights ?? utr?.Edit_Rights ?? 0,
                Delete_Rights: ur?.Delete_Rights ?? utr?.Delete_Rights ?? 0,
                Print_Rights: ur?.Print_Rights ?? utr?.Print_Rights ?? 0,
            };
        });

        return rows;
    } catch (e) {
        console.error('Error in getUserBasedRights:', e);
        return false;
    }
};

const getUserTypeBasedRights = async (userType: number, token: string | null): Promise<MenuRow[] | false> => {
    try {
        const companyDB = await getCompanyDB(token);

        const menus = await companyDB.query(
            `SELECT * FROM tbl_AppMenu`,
            { type: QueryTypes.SELECT }
        ) as MenuRow[];

        if (isEqualNumber(userType, 0) || isEqualNumber(userType, 1)) {
            const rows: MenuRow[] = menus.map(m => ({
                ...m,
                Read_Rights: 1,
                Add_Rights: 1,
                Edit_Rights: 1,
                Delete_Rights: 1,
                Print_Rights: 1,
            }));
            return rows;
        }

        let typeRights: any[] = [];
        try {
            typeRights = await companyDB.query(
                `SELECT MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights
                 FROM tbl_AppMenu_UserTypeRights
                 WHERE UserTypeId = :userType OR UserType = :userType`,
                { replacements: { userType }, type: QueryTypes.SELECT },
            ) as any[];
        } catch {
            typeRights = await companyDB.query(
                `SELECT MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights
                 FROM tbl_AppMenu_UserTypeRights
                 WHERE UserTypeId = :userType`,
                { replacements: { userType }, type: QueryTypes.SELECT },
            ) as any[];
        }

        const utrMap = new Map(typeRights.map(r => [r.MenuId, r]));

        const rows: MenuRow[] = menus.map(m => {
            const utr = utrMap.get(m.id);
            return {
                ...m,
                Read_Rights: utr?.Read_Rights ?? 0,
                Add_Rights: utr?.Add_Rights ?? 0,
                Edit_Rights: utr?.Edit_Rights ?? 0,
                Delete_Rights: utr?.Delete_Rights ?? 0,
                Print_Rights: utr?.Print_Rights ?? 0,
            };
        });

        return rows;
    } catch (e) {
        console.error('Error in getUserTypeBasedRights:', e);
        return false;
    }
};

// ─── Controller ───────────────────────────────────────────────────────────────

const appMenu = () => {

    const newAppMenu = async (req: Request, res: Response): Promise<void> => {
        try {
            const { MenuName, MenuId } = req.query as Record<string, string>;
            const token = extractToken(req);

            if (!token) {
                invalidInput(res, 'Authorization token required');
                return;
            }

            const userRights = await getUserMenuRights(token);

            if (!Array.isArray(userRights)) {
                failed(res, 'Unable to fetch menu rights');
                return;
            }

            const activeMenus = userRights.filter(m => isEqualNumber(m.is_active, 2));
            const subRoutings = activeMenus
                .filter(m => isEqualNumber(m.menu_type, 0))
                .sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));
            const nestedRoutes = buildRoutesTree(subRoutings);
            const menuStructure = buildMenuStructure(activeMenus);

            const filteredMenu = MenuName
                ? menuStructure.filter(m => stringCompare(m.name, MenuName))
                : isValidNumber(MenuId)
                    ? menuStructure.filter(m => isEqualNumber(m.id, MenuId))
                    : menuStructure;

            dataFound(res, filteredMenu, 'Data Found', { subRoutings, nestedRoutes });
        } catch (e) {
            servError(e, res);
        }
    };

    const userRights = async (req: Request, res: Response): Promise<void> => {
        try {
            const { UserId, MenuName, MenuId } = req.query as Record<string, string>;
            const token = extractToken(req);

            if (!token) {
                invalidInput(res, 'Authorization token required');
                return;
            }

            let userRightsData: MenuRow[] | false;

            if (UserId && isValidNumber(UserId)) {
                userRightsData = await getUserRightsForSpecificUser(Number(UserId), token);
            } else if (UserId && !isValidNumber(UserId)) {
                invalidInput(res, 'Invalid UserId parameter');
                return;
            } else {
                userRightsData = await getUserMenuRights(token);
            }

            if (!Array.isArray(userRightsData)) {
                failed(res, 'Unable to fetch user rights');
                return;
            }

            const activeMenus = userRightsData.filter(m => isEqualNumber(m.is_active, 2));
            const subRoutings = activeMenus
                .filter(m => isEqualNumber(m.menu_type, 0))
                .sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));
            const nestedRoutes = buildRoutesTree(subRoutings);
            const menuStructure = buildMenuStructure(activeMenus);

            const filteredMenu = MenuName
                ? menuStructure.filter(m => stringCompare(m.name, MenuName))
                : isValidNumber(MenuId)
                    ? menuStructure.filter(m => isEqualNumber(m.id, MenuId))
                    : menuStructure;

            dataFound(res, filteredMenu, 'Data Found', { subRoutings, nestedRoutes });
        } catch (e) {
            console.error('Error in userRights endpoint:', e);
            servError(e, res);
        }
    };

    const getNewUserBasedRights = async (req: Request, res: Response): Promise<void> => {
        try {
            const { UserId } = req.query as Record<string, string>;
            if (!isValidNumber(UserId)) {
                invalidInput(res, 'UserId is required');
                return;
            }

            const token = extractToken(req);
            const result = await getUserBasedRights(Number(UserId), token);

            if (!Array.isArray(result)) {
                failed(res);
                return;
            }

            const subRoutings = result.filter(m => isEqualNumber(m.menu_type, 0)).sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));
            const nestedRoutes = buildRoutesTree(subRoutings);
            const menuStructure = buildMenuStructure(result);

            dataFound(res, menuStructure, 'Data Found', { subRoutings, nestedRoutes });
        } catch (e) {
            console.error(e);
            servError(e, res);
        }
    };

    const getNewAuthBasedRights = async (req: Request, res: Response): Promise<void> => {
        try {
            const token = extractToken(req);
            const userInfo = await getUserInfoFromToken(token);
            const localUserId = userInfo?.localUserId || null;

            if (!localUserId) {
                failed(res, 'User not found');
                return;
            }

            const result = await getUserBasedRights(localUserId, token);

            if (!Array.isArray(result)) {
                failed(res);
                return;
            }

            const subRoutings = result.filter(m => isEqualNumber(m.menu_type, 0)).sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));
            const nestedRoutes = buildRoutesTree(subRoutings);
            const menuStructure = buildMenuStructure(result);

            dataFound(res, menuStructure, 'Data Found', { subRoutings, nestedRoutes });
        } catch (e) {
            console.error(e);
            servError(e, res);
        }
    };

    const newModifyUserRights = async (req: Request, res: Response): Promise<void> => {
        try {
            const token = extractToken(req);
            const companyDB = await getCompanyDB(token);

            if (!companyDB) {
                failed(res, 'Database connection unavailable');
                return;
            }

            const body = req.body;
            const rawBody = Array.isArray(body)
                ? body
                : (body?.userRights || body?.userTypeRights || body?.rights || body?.data || body?.items || body);
            const rawItems = Array.isArray(rawBody) ? rawBody : [rawBody];

            const parseRights = (val: any) => (val === 1 || val === '1' || val === true ? 1 : 0);

            const userItems: Array<{
                targetUserId: number;
                MenuId: number;
                ReadRights: number;
                AddRights: number;
                EditRights: number;
                DeleteRights: number;
                PrintRights: number;
            }> = [];

            const userTypeItems: Array<{
                targetUserTypeId: number;
                MenuId: number;
                ReadRights: number;
                AddRights: number;
                EditRights: number;
                DeleteRights: number;
                PrintRights: number;
            }> = [];

            rawItems.forEach(item => {
                if (!item || typeof item !== 'object') return;

                const menuIdRaw = item.MenuId ?? item.menuId ?? item.Menu_Id ?? item.menu_id ?? item.id ?? item.Id;
                const menuId = Number(menuIdRaw);
                if (!menuIdRaw || isNaN(menuId)) return;

                const readRights = parseRights(item.ReadRights ?? item.Read_Rights ?? item.readRights ?? item.read_rights);
                const addRights = parseRights(item.AddRights ?? item.Add_Rights ?? item.addRights ?? item.add_rights);
                const editRights = parseRights(item.EditRights ?? item.Edit_Rights ?? item.editRights ?? item.edit_rights);
                const deleteRights = parseRights(item.DeleteRights ?? item.Delete_Rights ?? item.deleteRights ?? item.delete_rights);
                const printRights = parseRights(item.PrintRights ?? item.Print_Rights ?? item.printRights ?? item.print_rights);

                const rawUserId = item.User ?? item.UserId ?? item.userId ?? item.user ?? item.User_Id ?? item.user_id;
                const numUserId = Number(rawUserId);

                if (rawUserId !== undefined && rawUserId !== null && !isNaN(numUserId) && numUserId > 0) {
                    userItems.push({
                        targetUserId: numUserId,
                        MenuId: menuId,
                        ReadRights: readRights,
                        AddRights: addRights,
                        EditRights: editRights,
                        DeleteRights: deleteRights,
                        PrintRights: printRights,
                    });
                }

                const rawUserTypeId = item.UserType ?? item.UserTypeId ?? item.userTypeId ?? item.userType ?? item.User_Type_Id ?? item.user_type_id;
                const numUserTypeId = Number(rawUserTypeId);

                if (rawUserTypeId !== undefined && rawUserTypeId !== null && !isNaN(numUserTypeId) && numUserTypeId > 0 && (rawUserId === undefined || rawUserId === null || numUserId <= 0)) {
                    userTypeItems.push({
                        targetUserTypeId: numUserTypeId,
                        MenuId: menuId,
                        ReadRights: readRights,
                        AddRights: addRights,
                        EditRights: editRights,
                        DeleteRights: deleteRights,
                        PrintRights: printRights,
                    });
                }
            });

            if (userItems.length > 0 || userTypeItems.length > 0) {
                await companyDB.transaction(async (t) => {
                    if (userItems.length > 0) {
                        const chunkSize = 100;
                        for (let i = 0; i < userItems.length; i += chunkSize) {
                            const chunk = userItems.slice(i, i + chunkSize);

                            const deleteClauses: string[] = [];
                            const deleteReplacements: Record<string, any> = {};
                            const insertValues: string[] = [];
                            const insertReplacements: Record<string, any> = {};

                            chunk.forEach((item, idx) => {
                                deleteClauses.push(`(UserId = :u${idx} AND MenuId = :m${idx})`);
                                deleteReplacements[`u${idx}`] = item.targetUserId;
                                deleteReplacements[`m${idx}`] = item.MenuId;

                                insertValues.push(`(:iu${idx}, :im${idx}, :ir${idx}, :ia${idx}, :ie${idx}, :id${idx}, :ip${idx})`);
                                insertReplacements[`iu${idx}`] = item.targetUserId;
                                insertReplacements[`im${idx}`] = item.MenuId;
                                insertReplacements[`ir${idx}`] = item.ReadRights;
                                insertReplacements[`ia${idx}`] = item.AddRights;
                                insertReplacements[`ie${idx}`] = item.EditRights;
                                insertReplacements[`id${idx}`] = item.DeleteRights;
                                insertReplacements[`ip${idx}`] = item.PrintRights;
                            });

                            await companyDB.query(
                                `DELETE FROM tbl_AppMenu_UserRights WHERE ${deleteClauses.join(' OR ')}`,
                                { replacements: deleteReplacements, type: QueryTypes.DELETE, transaction: t },
                            );

                            await companyDB.query(
                                `INSERT INTO tbl_AppMenu_UserRights
                                    (UserId, MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights)
                                 VALUES
                                    ${insertValues.join(',\n')}`,
                                { replacements: insertReplacements, type: QueryTypes.INSERT, transaction: t },
                            );
                        }
                    }

                    if (userTypeItems.length > 0) {
                        const chunkSize = 100;
                        for (let i = 0; i < userTypeItems.length; i += chunkSize) {
                            const chunk = userTypeItems.slice(i, i + chunkSize);

                            const deleteClauses: string[] = [];
                            const deleteReplacements: Record<string, any> = {};
                            const insertValues: string[] = [];
                            const insertReplacements: Record<string, any> = {};

                            chunk.forEach((item, idx) => {
                                deleteClauses.push(`(UserTypeId = :u${idx} AND MenuId = :m${idx})`);
                                deleteReplacements[`u${idx}`] = item.targetUserTypeId;
                                deleteReplacements[`m${idx}`] = item.MenuId;

                                insertValues.push(`(:iu${idx}, :im${idx}, :ir${idx}, :ia${idx}, :ie${idx}, :id${idx}, :ip${idx})`);
                                insertReplacements[`iu${idx}`] = item.targetUserTypeId;
                                insertReplacements[`im${idx}`] = item.MenuId;
                                insertReplacements[`ir${idx}`] = item.ReadRights;
                                insertReplacements[`ia${idx}`] = item.AddRights;
                                insertReplacements[`ie${idx}`] = item.EditRights;
                                insertReplacements[`id${idx}`] = item.DeleteRights;
                                insertReplacements[`ip${idx}`] = item.PrintRights;
                            });

                            await companyDB.query(
                                `DELETE FROM tbl_AppMenu_UserTypeRights WHERE ${deleteClauses.join(' OR ')}`,
                                { replacements: deleteReplacements, type: QueryTypes.DELETE, transaction: t },
                            );

                            await companyDB.query(
                                `INSERT INTO tbl_AppMenu_UserTypeRights
                                    (UserTypeId, MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights)
                                 VALUES
                                    ${insertValues.join(',\n')}`,
                                { replacements: insertReplacements, type: QueryTypes.INSERT, transaction: t },
                            );
                        }
                    }
                });
            }

            success(res, 'Changes saved successfully.');
        } catch (e) {
            console.error('Error in newModifyUserRights:', e);
            servError(e, res);
        }
    };

    const getNewUserTypeBasedRights = async (req: Request, res: Response): Promise<void> => {
        const { UserType, UserTypeId, userTypeId, userType } = req.query as Record<string, string>;
        const targetUserTypeId = UserType || UserTypeId || userTypeId || userType;
        if (!targetUserTypeId) {
            invalidInput(res, 'UserType is required');
            return;
        }

        try {
            const token = extractToken(req);
            const result = await getUserTypeBasedRights(Number(targetUserTypeId), token);

            if (!Array.isArray(result)) {
                failed(res);
                return;
            }

            const subRoutings = result.filter(m => isEqualNumber(m.menu_type, 0)).sort((a, b) => (a.parent_id ?? 0) - (b.parent_id ?? 0));
            const nestedRoutes = buildRoutesTree(subRoutings);
            const menuStructure = buildMenuStructure(result);

            dataFound(res, menuStructure, 'Data Found', { subRoutings, nestedRoutes });
        } catch (e) {
            console.error(e);
            servError(e, res);
        }
    };

    const newModifyUserTypeRights = async (req: Request, res: Response): Promise<void> => {
        try {
            const token = extractToken(req);
            const companyDB = await getCompanyDB(token);

            if (!companyDB) {
                failed(res, 'Database connection unavailable');
                return;
            }

            const body = req.body;
            const rawBody = Array.isArray(body)
                ? body
                : (body?.userTypeRights || body?.userRights || body?.rights || body?.data || body?.items || body);
            const rawItems = Array.isArray(rawBody) ? rawBody : [rawBody];

            const parseRights = (val: any) => (val === 1 || val === '1' || val === true ? 1 : 0);

            const userTypeItems: Array<{
                targetUserTypeId: number;
                MenuId: number;
                ReadRights: number;
                AddRights: number;
                EditRights: number;
                DeleteRights: number;
                PrintRights: number;
            }> = [];

            rawItems.forEach(item => {
                if (!item || typeof item !== 'object') return;

                const menuIdRaw = item.MenuId ?? item.menuId ?? item.Menu_Id ?? item.menu_id ?? item.id ?? item.Id;
                const menuId = Number(menuIdRaw);
                if (!menuIdRaw || isNaN(menuId)) return;

                const rawUserTypeId = item.UserType ?? item.UserTypeId ?? item.userTypeId ?? item.userType ?? item.User_Type_Id ?? item.user_type_id;
                const numUserTypeId = Number(rawUserTypeId);
                if (rawUserTypeId === undefined || rawUserTypeId === null || isNaN(numUserTypeId)) return;

                const readRights = parseRights(item.ReadRights ?? item.Read_Rights ?? item.readRights ?? item.read_rights);
                const addRights = parseRights(item.AddRights ?? item.Add_Rights ?? item.addRights ?? item.add_rights);
                const editRights = parseRights(item.EditRights ?? item.Edit_Rights ?? item.editRights ?? item.edit_rights);
                const deleteRights = parseRights(item.DeleteRights ?? item.Delete_Rights ?? item.deleteRights ?? item.delete_rights);
                const printRights = parseRights(item.PrintRights ?? item.Print_Rights ?? item.printRights ?? item.print_rights);

                userTypeItems.push({
                    targetUserTypeId: numUserTypeId,
                    MenuId: menuId,
                    ReadRights: readRights,
                    AddRights: addRights,
                    EditRights: editRights,
                    DeleteRights: deleteRights,
                    PrintRights: printRights,
                });
            });

            if (userTypeItems.length > 0) {
                await companyDB.transaction(async (t) => {
                    const chunkSize = 100;
                    for (let i = 0; i < userTypeItems.length; i += chunkSize) {
                        const chunk = userTypeItems.slice(i, i + chunkSize);

                        const deleteClauses: string[] = [];
                        const deleteReplacements: Record<string, any> = {};

                        const insertValues: string[] = [];
                        const insertReplacements: Record<string, any> = {};

                        chunk.forEach((item, idx) => {
                            deleteClauses.push(`(UserTypeId = :u${idx} AND MenuId = :m${idx})`);
                            deleteReplacements[`u${idx}`] = item.targetUserTypeId;
                            deleteReplacements[`m${idx}`] = item.MenuId;

                            insertValues.push(`(:iu${idx}, :im${idx}, :ir${idx}, :ia${idx}, :ie${idx}, :id${idx}, :ip${idx})`);
                            insertReplacements[`iu${idx}`] = item.targetUserTypeId;
                            insertReplacements[`im${idx}`] = item.MenuId;
                            insertReplacements[`ir${idx}`] = item.ReadRights;
                            insertReplacements[`ia${idx}`] = item.AddRights;
                            insertReplacements[`ie${idx}`] = item.EditRights;
                            insertReplacements[`id${idx}`] = item.DeleteRights;
                            insertReplacements[`ip${idx}`] = item.PrintRights;
                        });

                        await companyDB.query(
                            `DELETE FROM tbl_AppMenu_UserTypeRights WHERE ${deleteClauses.join(' OR ')}`,
                            { replacements: deleteReplacements, type: QueryTypes.DELETE, transaction: t },
                        );

                        await companyDB.query(
                            `INSERT INTO tbl_AppMenu_UserTypeRights
                                (UserTypeId, MenuId, Read_Rights, Add_Rights, Edit_Rights, Delete_Rights, Print_Rights)
                             VALUES
                                ${insertValues.join(',\n')}`,
                            { replacements: insertReplacements, type: QueryTypes.INSERT, transaction: t },
                        );
                    }
                });
            }

            success(res, 'Changes saved successfully.');
        } catch (e) {
            console.error('Error in newModifyUserTypeRights:', e);
            servError(e, res);
        }
    };

    const createNewMenu = async (req: Request, res: Response): Promise<void> => {
        const {
            name, menu_type, parent_id, url, tUrl, rUrl,
            display_order, is_active = 2, actionType = 'internal',
        } = req.body as CreateMenuBody;

        const token = extractToken(req);

        if (!token) {
            invalidInput(res, 'Authorization token required');
            return;
        }

        const companyDB = await getCompanyDB(token);

        try {
            await companyDB.query(
                `INSERT INTO tbl_AppMenu
                    (name, menu_type, parent_id, url, tUrl, rUrl, actionType, display_order, is_active)
                 VALUES
                    (:name, :menu_type, :parent_id, :url, :tUrl, :rUrl, :actionType, :display_order, :is_active)`,
                {
                    replacements: {
                        name, menu_type,
                        parent_id: parent_id ?? null,
                        url, tUrl, rUrl, actionType, display_order, is_active,
                    },
                    type: QueryTypes.INSERT,
                },
            );

            success(res, 'New Menu Added');
        } catch (e) {
            servError(e, res);
        }
    };

    const updateMenu = async (req: Request, res: Response): Promise<void> => {
        const {
            id, name, menu_type, parent_id, url, tUrl, rUrl,
            display_order, is_active = 2, actionType = 'internal',
        } = req.body as UpdateMenuBody;

        const token = extractToken(req);

        if (!token) {
            invalidInput(res, 'Authorization token required');
            return;
        }

        const companyDB = await getCompanyDB(token);

        try {
            await companyDB.query(
                `UPDATE tbl_AppMenu SET
                    name = :name,
                    menu_type = :menu_type,
                    parent_id = :parent_id,
                    url = :url,
                    tUrl = :tUrl,
                    rUrl = :rUrl,
                    actionType = :actionType,
                    display_order = :display_order,
                    is_active = :is_active
                 WHERE id = :id`,
                {
                    replacements: {
                        id, name, menu_type,
                        parent_id: parent_id ?? null,
                        url, tUrl, rUrl, actionType, display_order, is_active,
                    },
                    type: QueryTypes.UPDATE,
                },
            );

            success(res, 'Changes Saved');
        } catch (e) {
            servError(e, res);
        }
    };

    const listMenu = async (req: Request, res: Response): Promise<void> => {
        const token = extractToken(req);

        if (!token) {
            invalidInput(res, 'Authorization token required');
            return;
        }

        const companyDB = await getCompanyDB(token);

        try {
            const allMenus = await companyDB.query(
                `SELECT * FROM tbl_AppMenu`,
                { type: QueryTypes.SELECT }
            ) as MenuRow[];

            if (!allMenus.length) {
                failed(res);
                return;
            }

            const menuMap = new Map<number, MenuRow>(allMenus.map(m => [m.id, m]));

            const result: (MenuRow & { ParantData: MenuRow | Record<string, never> })[] =
                allMenus.map(m => ({
                    ...m,
                    ParantData: m.parent_id != null ? (menuMap.get(m.parent_id) ?? {}) : {},
                }));

            const menuStructure = buildMenuStructure(result);

            if (menuStructure.length > 0) {
                dataFound(res, menuStructure);
            } else {
                failed(res);
            }
        } catch (e) {
            servError(e, res);
        }
    };

    return {
        newAppMenu,
        userRights,
        getNewUserBasedRights,
        getNewAuthBasedRights,
        newModifyUserRights,
        getNewUserTypeBasedRights,
        newModifyUserTypeRights,
        createNewMenu,
        updateMenu,
        listMenu,
    };
};

export default appMenu();