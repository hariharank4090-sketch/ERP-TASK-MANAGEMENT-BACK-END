import { Request, Response } from 'express';
import { Sequelize, QueryTypes, Transaction } from 'sequelize';
import { ZodError } from 'zod';
import {
    created,
    updated,
    deleted,
    servError,
    notFound,
    sentData
} from '../../../responseObject';
import {
    ScheduleCreateSchema,
    ScheduleUpdateSchema,
    ScheduleQuerySchema,
    ScheduleIdSchema,
    ScheduleStatusUpdateSchema,
    ScheduleCreate,
    ScheduleUpdate,
    ScheduleQuery,
    ScheduleStatusUpdate
} from '../../../models/masters/ProjectSchedule/schedule.type.model';
import { invalidateTaskDetailCache } from './projectScheduleEmp.controller';

// Helper to get database from request (using companyDB from auth middleware)
const getDb = (req: Request): Sequelize => {
    if (req.companyDB) {
        return req.companyDB;
    }
    throw new Error('Database connection not available. Please authenticate first.');
};

const getCurrentDatabaseName = (req: Request): string => {
    return req.currentDBName || 'default';
};

const validateWithZod = <T>(schema: any, data: any): {
    success: boolean;
    data?: T;
    errors?: Array<{ field: string; message: string }>;
} => {
    try {
        return { success: true, data: schema.parse(data) };
    } catch (error) {
        if (error instanceof ZodError) {
            return {
                success: false,
                errors: error.issues.map(err => ({
                    field: err.path.join('.') || 'unknown',
                    message: err.message
                }))
            };
        }
        return {
            success: false,
            errors: [{ field: 'unknown', message: 'Validation failed' }]
        };
    }
};

const formatDateForSQL = (date: Date | string | null): string | null => {
    if (!date) return null;

    let d: Date;
    if (typeof date === 'string') {
        // Check if it's DD-MM-YYYY
        const parts = date.split('-');
        if (parts.length === 3 && parts[0].length === 2 && parts[2].length === 4) {
            d = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
        } else {
            d = new Date(date);
        }
    } else {
        d = date;
    }

    if (isNaN(d.getTime())) return null;

    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
};

const validateDateRange = (
    startDate: Date | string | null | undefined,
    endDate: Date | string | null | undefined
): { valid: boolean; message?: string } => {
    if (!startDate || !endDate) return { valid: true };
    const start = new Date(startDate);
    const end = new Date(endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return { valid: false, message: 'Invalid date format' };
    }
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    if (end < start) {
        return { valid: false, message: 'End date must be on or after start date' };
    }
    return { valid: true };
};

async function insertTaskDates(
    db: Sequelize,
    schId: number,
    dates: Date[],
    estStartTime: string | null,
    estEndTime: string | null,
    transaction: Transaction
): Promise<void> {
    if (!dates || dates.length === 0) return;

    // Check if A_Id is an IDENTITY column
    const identityCheck = await db.query(
        `SELECT COLUMNPROPERTY(OBJECT_ID('tbl_Project_Sch_Task_DT'), 'A_Id', 'IsIdentity') AS isIdentity`,
        { type: QueryTypes.SELECT, transaction }
    ) as any[];

    const isIdentity = identityCheck[0]?.isIdentity === 1;

    if (isIdentity) {
        const valuePlaceholders = dates.map(() => '(?, ?, ?, ?)').join(', ');
        const replacements: any[] = [];
        for (const date of dates) {
            replacements.push(schId, formatDateForSQL(date), estStartTime, estEndTime);
        }
        await db.query(
            `INSERT INTO tbl_Project_Sch_Task_DT
             (Sch_Id, Task_Work_Date, Task_Start_Time, Task_End_Time)
             VALUES ${valuePlaceholders}`,
            { replacements, type: QueryTypes.INSERT, transaction }
        );
    } else {
        // Atomic primary key generation inside transaction using UPDLOCK, HOLDLOCK
        const maxResult = await db.query(
            `SELECT ISNULL(MAX(A_Id), 0) as maxId FROM tbl_Project_Sch_Task_DT WITH (UPDLOCK, HOLDLOCK)`,
            { type: QueryTypes.SELECT, transaction }
        ) as any[];

        let currentAId = Number(maxResult[0]?.maxId || 0);
        const valuePlaceholders = dates.map(() => '(?, ?, ?, ?, ?)').join(', ');
        const replacements: any[] = [];
        for (const date of dates) {
            currentAId++;
            replacements.push(currentAId, schId, formatDateForSQL(date), estStartTime, estEndTime);
        }
        await db.query(
            `INSERT INTO tbl_Project_Sch_Task_DT
             (A_Id, Sch_Id, Task_Work_Date, Task_Start_Time, Task_End_Time)
             VALUES ${valuePlaceholders}`,
            { replacements, type: QueryTypes.INSERT, transaction }
        );
    }
}

async function insertPlanDetails(
    db: Sequelize,
    schId: number,
    planId: number,
    selectedDays: number[],
    planDetails: any,
    transaction: Transaction
): Promise<void> {
    // Plan 1 (Time/Daily), Plan 5 (Specific) do not store plan detail rows
    if (planId === 1 || planId === 5) return;
    if (!selectedDays || selectedDays.length === 0) return;

    for (const day of selectedDays) {
        await db.query(
            `INSERT INTO tbl_Project_Sch_DT (Sch_Id, Plan_Month, Plan_Day)
             VALUES (?, ?, ?)`,
            {
                replacements: [
                    schId,
                    (planId === 2 || planId === 3) ? null : (planDetails?.Plan_Month ?? null),
                    day
                ],
                type: QueryTypes.INSERT,
                transaction
            }
        );
    }
}

// Day-of-week helper: 1 = Monday … 7 = Sunday
function getDayOfWeek(date: Date): number {
    const day = date.getDay();
    return day === 0 ? 7 : day;
}

function generateTaskDates(
    startDate: Date,
    endDate: Date,
    planId: number,
    selectedDays: number[],
    _planDetails?: any,
    _specificDates: string[] = []
): Date[] {
    const dates: Date[] = [];
    const currentDate = new Date(startDate);

    while (currentDate <= endDate) {
        let includeDate = false;

        switch (planId) {
            case 1: // Daily — every day
                includeDate = true;
                break;
            case 2: // Days — weekdays 1-7
                includeDate = selectedDays.includes(getDayOfWeek(currentDate));
                break;
            case 3: // Weekly — weekdays 1-7
                includeDate = selectedDays.includes(getDayOfWeek(currentDate));
                break;
            case 4: // Monthly — day of month 1-31
                includeDate = selectedDays.includes(currentDate.getDate());
                break;
            default:
                includeDate = true;
        }

        if (includeDate) {
            dates.push(new Date(currentDate));
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }

    return dates;
}

// Helper function to convert string date to Date object without timezone issues and handling ISO strings safely
const parseDateString = (dateString: string): Date => {
    if (!dateString) throw new Error('Invalid date');
    const d = new Date(dateString);
    if (isNaN(d.getTime())) {
        const parts = dateString.split('-');
        if (parts.length === 3 && parts[2].length === 4) {
            const fallback = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
            if (!isNaN(fallback.getTime())) return fallback;
        }
        throw new Error('Invalid date');
    }
    return d;
};

// In-memory cache for getAllSchedules
interface ScheduleCacheEntry {
    data: any;
    expiry: number;
}
const scheduleListCache = new Map<string, ScheduleCacheEntry>();
const SCHEDULE_CACHE_TTL = 5000; // 5 seconds cache

export const invalidateScheduleCache = () => {
    scheduleListCache.clear();
    try {
        invalidateTaskDetailCache();
    } catch {
        // ignore
    }
};

export const DEFAULT_SCHEDULE_PLANS: Array<{ value: number; label: string }> = [
    { value: 1, label: 'Time Based' },
    { value: 2, label: 'Day Based' },
    { value: 3, label: 'Weekly Based' },
    { value: 4, label: 'Monthly Based' },
    { value: 5, label: 'Specific Day' }
];

export const resolvePlanTypeName = (
    rawPlanType: any,
    schPlanId?: any,
    schType?: any
): string => {
    if (typeof rawPlanType === 'string' && rawPlanType.trim() !== '' && isNaN(Number(rawPlanType.trim()))) {
        return rawPlanType.trim();
    }
    const planIdNum = Number(schPlanId ?? rawPlanType);
    const found = DEFAULT_SCHEDULE_PLANS.find(p => p.value === planIdNum);
    if (found) return found.label;

    const schTypeNum = Number(schType);
    if (schTypeNum === 1) return 'Specific Day';
    if (schTypeNum === 2) return 'Time Based';
    return 'Time Based';
};

const seededPlanDbs = new WeakSet<Sequelize>();

export const ensureSchPlanTableSeeded = async (db: Sequelize): Promise<void> => {
    if (seededPlanDbs.has(db)) return;
    try {
        await db.query(`
            IF OBJECT_ID('[dbo].[tbl_Sch_Plan]', 'U') IS NULL
            BEGIN
                CREATE TABLE [dbo].[tbl_Sch_Plan] (
                    [Plan_Id] INT PRIMARY KEY,
                    [Plan_Type] NVARCHAR(100) NOT NULL,
                    [Plan_Desc] NVARCHAR(255) NULL
                );
            END

            IF OBJECT_ID('[dbo].[tbl_Sch_Plan]', 'U') IS NOT NULL
            BEGIN
                IF COLUMNPROPERTY(OBJECT_ID('[dbo].[tbl_Sch_Plan]'), 'Plan_Id', 'IsIdentity') = 1
                BEGIN
                    SET IDENTITY_INSERT [dbo].[tbl_Sch_Plan] ON;
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 1)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (1, 'Time Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 2)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (2, 'Day Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 3)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (3, 'Weekly Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 4)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (4, 'Monthly Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 5)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (5, 'Specific Day');
                    SET IDENTITY_INSERT [dbo].[tbl_Sch_Plan] OFF;
                END
                ELSE
                BEGIN
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 1)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (1, 'Time Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 2)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (2, 'Day Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 3)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (3, 'Weekly Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 4)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (4, 'Monthly Based');
                    IF NOT EXISTS (SELECT 1 FROM [dbo].[tbl_Sch_Plan] WHERE [Plan_Id] = 5)
                        INSERT INTO [dbo].[tbl_Sch_Plan] ([Plan_Id], [Plan_Type]) VALUES (5, 'Specific Day');
                END
            END
        `);
        seededPlanDbs.add(db);
    } catch (err: any) {
        console.warn('⚠️ ensureSchPlanTableSeeded warning:', err.message);
    }
};

export const syncTicketScheduleStatuses = async (db: Sequelize): Promise<void> => {
    try {
        await db.query(`
            IF OBJECT_ID('[dbo].[tbl_Project_Schedule]', 'U') IS NOT NULL
               AND OBJECT_ID('[dbo].[tbl_Ticket_Gen_Info]', 'U') IS NOT NULL
            BEGIN
                EXEC sp_executesql N'
                    UPDATE s
                    SET s.[Sch_Status] = mapped.[Target_Sch_Status],
                        s.[Sch_Comp_Date] = CASE WHEN mapped.[Target_Sch_Status] = 3 THEN ISNULL(s.[Sch_Comp_Date], GETDATE()) ELSE NULL END,
                        s.[Update_Date] = GETDATE()
                    FROM [dbo].[tbl_Project_Schedule] s
                    INNER JOIN [dbo].[tbl_Ticket_Gen_Info] tk
                        ON s.[Sch_No] LIKE ''TCK-%''
                       AND TRY_CAST(
                            REPLACE(
                                LEFT(
                                    SUBSTRING(s.[Sch_No], 5, 50),
                                    CASE
                                        WHEN CHARINDEX(''-'', SUBSTRING(s.[Sch_No], 5, 50)) > 0
                                        THEN CHARINDEX(''-'', SUBSTRING(s.[Sch_No], 5, 50)) - 1
                                        ELSE LEN(SUBSTRING(s.[Sch_No], 5, 50))
                                    END
                                ),
                                '' '',
                                ''''
                            ) AS BIGINT
                        ) = tk.[Id]
                    CROSS APPLY (
                        SELECT CASE
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''closed'' THEN 3
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''pending'' THEN 2
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) IN (''new'', ''assigned'', ''inprocess'', ''in progress'', ''open'') THEN 1
                            ELSE NULL
                        END AS [Target_Sch_Status]
                    ) mapped
                    WHERE s.[Sch_Del_Flag] = 0
                      AND mapped.[Target_Sch_Status] IS NOT NULL
                      AND ISNULL(s.[Sch_Status], 0) <> mapped.[Target_Sch_Status];
                ';
            END

            IF OBJECT_ID('[dbo].[tbl_Project_Schedule]', 'U') IS NOT NULL
               AND OBJECT_ID('[dbo].[tbl_Project_Ticket]', 'U') IS NOT NULL
               AND OBJECT_ID('[dbo].[tbl_Ticket_Gen_Info]', 'U') IS NOT NULL
            BEGIN
                EXEC sp_executesql N'
                    UPDATE s
                    SET s.[Sch_Status] = mapped.[Target_Sch_Status],
                        s.[Sch_Comp_Date] = CASE WHEN mapped.[Target_Sch_Status] = 3 THEN ISNULL(s.[Sch_Comp_Date], GETDATE()) ELSE NULL END,
                        s.[Update_Date] = GETDATE()
                    FROM [dbo].[tbl_Project_Schedule] s
                    INNER JOIN [dbo].[tbl_Project_Ticket] pt ON pt.[Task_Id] = s.[Task_Id]
                    INNER JOIN [dbo].[tbl_Ticket_Gen_Info] tk ON TRY_CAST(pt.[Ticket_Id] AS BIGINT) = tk.[Id]
                    CROSS APPLY (
                        SELECT CASE
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''closed'' THEN 3
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''pending'' THEN 2
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) IN (''new'', ''assigned'', ''inprocess'', ''in progress'', ''open'') THEN 1
                            ELSE NULL
                        END AS [Target_Sch_Status]
                    ) mapped
                    WHERE s.[Sch_Del_Flag] = 0
                      AND mapped.[Target_Sch_Status] IS NOT NULL
                      AND ISNULL(s.[Sch_Status], 0) <> mapped.[Target_Sch_Status];
                ';
            END

            IF OBJECT_ID('[dbo].[tbl_Project_Schedule]', 'U') IS NOT NULL
               AND OBJECT_ID('[dbo].[tbl_Ticket_Alloctation]', 'U') IS NOT NULL
               AND OBJECT_ID('[dbo].[tbl_Ticket_Gen_Info]', 'U') IS NOT NULL
            BEGIN
                EXEC sp_executesql N'
                    UPDATE s
                    SET s.[Sch_Status] = mapped.[Target_Sch_Status],
                        s.[Sch_Comp_Date] = CASE WHEN mapped.[Target_Sch_Status] = 3 THEN ISNULL(s.[Sch_Comp_Date], GETDATE()) ELSE NULL END,
                        s.[Update_Date] = GETDATE()
                    FROM [dbo].[tbl_Project_Schedule] s
                    INNER JOIN [dbo].[tbl_Ticket_Alloctation] a ON a.[T_Sch_Id] = s.[Sch_Id]
                    INNER JOIN [dbo].[tbl_Ticket_Gen_Info] tk ON a.[Ticket_Id] = tk.[Id]
                    CROSS APPLY (
                        SELECT CASE
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''closed'' THEN 3
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) = ''pending'' THEN 2
                            WHEN LOWER(LTRIM(RTRIM(ISNULL(tk.[Status], '''')))) IN (''new'', ''assigned'', ''inprocess'', ''in progress'', ''open'') THEN 1
                            ELSE NULL
                        END AS [Target_Sch_Status]
                    ) mapped
                    WHERE s.[Sch_Del_Flag] = 0
                      AND mapped.[Target_Sch_Status] IS NOT NULL
                      AND ISNULL(s.[Sch_Status], 0) <> mapped.[Target_Sch_Status];
                ';
            END
        `);
    } catch (err: any) {
        console.warn('⚠️ syncTicketScheduleStatuses warning:', err.message);
    }
};

export const getAllSchedules = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        await ensureSchPlanTableSeeded(db);
        await syncTicketScheduleStatuses(db);

        const validation = validateWithZod<ScheduleQuery>(ScheduleQuerySchema, req.query);
        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Invalid query parameters',
                errors: validation.errors
            });
        }

        const cacheKey = `${currentDBName}_schedules_${JSON.stringify(req.query)}`;
        const cached = scheduleListCache.get(cacheKey);
        if (cached && Date.now() < cached.expiry) {
            return res.status(200).json(cached.data);
        }

        const { status, planType, taskId, dateFrom, dateTo, search, page = 1, limit = 20, sortBy = 'Sch_Id', sortOrder = 'DESC' } = validation.data!;

        const offset = (page - 1) * limit;

        let whereConditions = ['s.Sch_Del_Flag = 0'];
        const replacements: any[] = [];

        if (search) {
            whereConditions.push(`(s.Sch_No LIKE ? OR t.Task_Name LIKE ?)`);
            replacements.push(`%${search}%`, `%${search}%`);
        }
        if (status !== undefined) {
            whereConditions.push(`s.Sch_Status = ?`);
            replacements.push(status);
        }
        if (planType) {
            whereConditions.push(`s.Sch_Plan_Id = ?`);
            replacements.push(planType);
        }
        if (taskId) {
            whereConditions.push(`s.Task_Id = ?`);
            replacements.push(taskId);
        }
        if (dateFrom) {
            whereConditions.push(`s.Sch_Date >= ?`);
            replacements.push(formatDateForSQL(dateFrom));
        }
        if (dateTo) {
            whereConditions.push(`s.Sch_Date <= ?`);
            replacements.push(formatDateForSQL(dateTo));
        }

        const whereClause = whereConditions.length > 0 ? 'WHERE ' + whereConditions.join(' AND ') : '';

        const countQuery = `
            SELECT COUNT(*) as total
            FROM tbl_Project_Schedule s WITH (NOLOCK)
            ${search ? 'LEFT JOIN tbl_Task t WITH (NOLOCK) ON s.Task_Id = t.Task_Id' : ''}
            ${whereClause}
        `;

        let sortColumn = 's.Sch_Id';
        if (sortBy === 'Sch_No') sortColumn = 's.Sch_No';
        else if (sortBy === 'Sch_Date') sortColumn = 's.Sch_Date';
        else if (sortBy === 'Task_Name') sortColumn = 't.Task_Name';
        else if (sortBy === 'Sch_Status') sortColumn = 's.Sch_Status';
        else if (sortBy === 'Entry_Date') sortColumn = 's.Entry_Date';

        const orderClause = `ORDER BY ${sortColumn} ${sortOrder === 'ASC' ? 'ASC' : 'DESC'}`;

        const schedulesQuery = `
            SELECT
                s.*, t.Task_Name,
                COALESCE(
                    NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                    CASE s.Sch_Plan_Id
                        WHEN 1 THEN 'Time Based'
                        WHEN 2 THEN 'Day Based'
                        WHEN 3 THEN 'Weekly Based'
                        WHEN 4 THEN 'Monthly Based'
                        WHEN 5 THEN 'Specific Day'
                        ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                    END
                ) as Plan_Type,
                pm.Project_Name, pm.Project_Id,
                COALESCE(tc.empCount, 0) as empCount,
                CASE WHEN COALESCE(ec.extCount, 0) > 0 THEN 1 ELSE 0 END as hasExtension
            FROM tbl_Project_Schedule s WITH (NOLOCK)
            LEFT JOIN tbl_Task t WITH (NOLOCK) ON s.Task_Id = t.Task_Id
            LEFT JOIN tbl_Project_Master pm WITH (NOLOCK) ON t.Project_Id = pm.Project_Id
            LEFT JOIN tbl_Sch_Plan p WITH (NOLOCK) ON s.Sch_Plan_Id = p.Plan_Id
            OUTER APPLY (
                SELECT COUNT(DISTINCT td.Emp_Id) as empCount
                FROM tbl_Task_Details td WITH (NOLOCK)
                WHERE td.Sch_Id = s.Sch_Id
            ) tc
            OUTER APPLY (
                SELECT TOP 1 1 as extCount
                FROM tbl_Project_Schedule_Extend ec WITH (NOLOCK)
                WHERE ec.Sch_Id = s.Sch_Id
            ) ec
            ${whereClause}
            ${orderClause}
            OFFSET ${offset} ROWS FETCH NEXT ${limit} ROWS ONLY
        `;

        const [countResult, schedules] = await Promise.all([
            db.query(countQuery, { replacements, type: QueryTypes.SELECT }) as Promise<any[]>,
            db.query(schedulesQuery, { replacements, type: QueryTypes.SELECT }) as Promise<any[]>
        ]);

        const totalRecords = countResult[0]?.total || 0;
        const totalPages = Math.ceil(totalRecords / limit);

        if (schedules.length === 0) {
            const emptyResponse = {
                success: true,
                message: 'Project schedules retrieved successfully',
                data: [],
                total: 0,
                totalPages: 0
            };
            scheduleListCache.set(cacheKey, { data: emptyResponse, expiry: Date.now() + SCHEDULE_CACHE_TTL });
            return res.status(200).json(emptyResponse);
        }

        const scheduleIds = schedules.map(s => s.Sch_Id);
        const scheduleIdsStr = scheduleIds.join(',');

        // Optimize child queries by filtering using IN clause for paginated schedule IDs with NOLOCK
        const taskDatesQuery = `
            SELECT dt.A_Id, dt.Sch_Id, dt.Task_Work_Date, dt.Task_Start_Time, dt.Task_End_Time
            FROM tbl_Project_Sch_Task_DT dt WITH (NOLOCK)
            WHERE dt.Sch_Id IN (${scheduleIdsStr})
            ORDER BY dt.Sch_Id, dt.Task_Work_Date
        `;

        const planDetailsQuery = `
            SELECT pd.Sch_Id, pd.Plan_Month, pd.Plan_Day
            FROM tbl_Project_Sch_DT pd WITH (NOLOCK)
            WHERE pd.Sch_Id IN (${scheduleIdsStr})
        `;

        const [taskDates, planDetails] = await Promise.all([
            db.query(taskDatesQuery, { type: QueryTypes.SELECT }) as Promise<any[]>,
            db.query(planDetailsQuery, { type: QueryTypes.SELECT }) as Promise<any[]>
        ]);

        const taskDatesByScheduleId: { [key: number]: any[] } = {};
        const planDetailsByScheduleId: { [key: number]: any[] } = {};

        taskDates.forEach((task: any) => {
            if (!taskDatesByScheduleId[task.Sch_Id]) taskDatesByScheduleId[task.Sch_Id] = [];
            taskDatesByScheduleId[task.Sch_Id].push({
                aId: task.A_Id,
                taskWorkDate: task.Task_Work_Date,
                taskStartTime: task.Task_Start_Time,
                taskEndTime: task.Task_End_Time
            });
        });

        planDetails.forEach((plan: any) => {
            if (!planDetailsByScheduleId[plan.Sch_Id]) planDetailsByScheduleId[plan.Sch_Id] = [];
            planDetailsByScheduleId[plan.Sch_Id].push({
                planMonth: plan.Plan_Month,
                planDay: plan.Plan_Day
            });
        });

        const formattedSchedules = schedules.map((schedule: any) => {
            const resolvedPlan = resolvePlanTypeName(schedule.Plan_Type, schedule.Sch_Plan_Id, schedule.Sch_Type);
            return {
                schId: schedule.Sch_Id,
                schNo: schedule.Sch_No,
                schDate: schedule.Sch_Date,
                Task_Id: schedule.Task_Id,
                Task_Name: schedule.Task_Name,
                TaskTypeId: schedule.Task_Type_Id,
                schPlanId: schedule.Sch_Plan_Id,
                schType: schedule.Sch_Type,
                Project_Id: schedule.Project_Id,
                Project_Name: schedule.Project_Name,
                planType: resolvedPlan,
                Plan_Type: resolvedPlan,
                schStartDate: schedule.Sch_Start_Date,
                schEndDate: schedule.Sch_End_Date,
                schFirstStartDate: schedule.Sch_First_Start_Date,
                schFirstEndDate: schedule.Sch_First_End_Date,
                taskSchTimerBased: schedule.Task_Sch_Timer_Based,
                schEstStartTime: schedule.Sch_Est_Start_Time,
                schEstEndTime: schedule.Sch_Est_End_Time,
                taskSchDuration: schedule.Task_Sch_Duaration,
                schStatus: schedule.Sch_Status,
                empCount: schedule.empCount,
                hasExtension: schedule.hasExtension,
                schCompDate: schedule.Sch_Comp_Date,
                entryBy: schedule.Entry_By,
                entryDate: schedule.Entry_Date,
                updateBy: schedule.Update_By,
                updateDate: schedule.Update_Date,
                taskDates: taskDatesByScheduleId[schedule.Sch_Id] || [],
                planDetails: planDetailsByScheduleId[schedule.Sch_Id] || []
            };
        });

        const responsePayload = {
            success: true,
            message: 'Project schedules retrieved successfully',
            data: formattedSchedules,
            total: totalRecords,
            totalPages: totalPages
        };
        scheduleListCache.set(cacheKey, { data: responsePayload, expiry: Date.now() + SCHEDULE_CACHE_TTL });

        res.status(200).json(responsePayload);
    } catch (e) {
        console.error('Error in getAllSchedules:', e);
        servError(e, res);
    }
};

export const getScheduleById = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        await ensureSchPlanTableSeeded(db);
        await syncTicketScheduleStatuses(db);

        const validation = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!validation.success) {
            return res.status(400).json({ success: false, errors: validation.errors });
        }

        const query = `
            SELECT s.*, t.Task_Name,
                   COALESCE(
                       NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                       CASE s.Sch_Plan_Id
                           WHEN 1 THEN 'Time Based'
                           WHEN 2 THEN 'Day Based'
                           WHEN 3 THEN 'Weekly Based'
                           WHEN 4 THEN 'Monthly Based'
                           WHEN 5 THEN 'Specific Day'
                           ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                       END
                   ) as Plan_Type,
                   pm.Project_Name, pm.Project_Id
            FROM tbl_Project_Schedule s
            LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
            LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
            LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
            WHERE s.Sch_Id = ? AND s.Sch_Del_Flag = 0
        `;

        const rows = await db.query(query, { replacements: [validation.data!.id], type: QueryTypes.SELECT }) as any[];
        if (!rows.length) return notFound(res, 'Project schedule not found');

        const detailsQuery = `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`;
        const details = await db.query(detailsQuery, { replacements: [validation.data!.id], type: QueryTypes.SELECT }) as any[];

        const planDtQuery = `SELECT * FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`;
        const planDt = await db.query(planDtQuery, { replacements: [validation.data!.id], type: QueryTypes.SELECT }) as any[];

        const resolvedPlan = resolvePlanTypeName(rows[0].Plan_Type, rows[0].Sch_Plan_Id, rows[0].Sch_Type);
        sentData(res, { ...rows[0], Plan_Type: resolvedPlan, planType: resolvedPlan, taskDates: details, planDetails: planDt });
    } catch (e) {
        console.error('Error in getScheduleById:', e);
        servError(e, res);
    }
};

export const getScheduleDetails = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const validation = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!validation.success) {
            return res.status(400).json({ success: false, errors: validation.errors });
        }

        const query = `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`;
        const rows = await db.query(query, { replacements: [validation.data!.id], type: QueryTypes.SELECT }) as any[];
        sentData(res, rows);
    } catch (e) {
        console.error('Error in getScheduleDetails:', e);
        servError(e, res);
    }
};

// export const createSchedule = async (req: Request, res: Response) => {
//     let transaction: Transaction | null = null;
//     let isTransactionActive = false;

//     try {
//         const db = getDb(req);
//         const currentDBName = getCurrentDatabaseName(req);
//         console.log(`📊 Creating schedule in database: ${currentDBName}`);
//         console.log('Create Schedule Request Body:', JSON.stringify(req.body, null, 2));

//         const body = {
//             ...req.body,
//             Sch_No: req.body.Sch_No?.trim(),
//             Sch_Status: req.body.Sch_Status || 1
//         };

//         const validation = validateWithZod<ScheduleCreate>(ScheduleCreateSchema, body);
//         if (!validation.success) {
//             console.log('Validation Errors:', JSON.stringify(validation.errors, null, 2));
//             return res.status(400).json({
//                 success: false,
//                 message: 'Validation failed',
//                 errors: validation.errors
//             });
//         }

//         const {
//             Sch_No,
//             Sch_Date,
//             Task_Id,
//             Task_Type_Id,
//             Sch_Plan_Id,
//             Sch_Type,
//             Task_Sch_Timer_Based,
//             Sch_Est_Start_Time,
//             Sch_Est_End_Time,
//             Task_Sch_Duaration,
//             Sch_Status,
//             Entry_By,
//             planDetails,
//             selectedDays,
//             specificDates
//         } = validation.data!;

//         // Default values from frontend
//         let Sch_Start_Date = validation.data!.Sch_Start_Date;
//         let Sch_End_Date = validation.data!.Sch_End_Date;

//         // PLAN 5 => AUTO SET START/END DATE FROM specificDates
//         if (
//             Sch_Plan_Id === 5 &&
//             specificDates &&
//             specificDates.length > 0
//         ) {
//             // Sort dates ascending (string sort works for YYYY-MM-DD format)
//             const sortedDates = [...specificDates].sort();

//             // First date = Start Date (convert string to Date)
//             Sch_Start_Date = parseDateString(sortedDates[0]);

//             // Last date = End Date (convert string to Date)
//             Sch_End_Date = parseDateString(sortedDates[sortedDates.length - 1]);

//             console.log('Plan 5 Auto Start Date:', Sch_Start_Date);
//             console.log('Plan 5 Auto End Date:', Sch_End_Date);
//         }

//         // For Plan 5, we don't need to validate date range as we use specificDates
//         if (Sch_Plan_Id !== 5) {
//             const dateValidation = validateDateRange(Sch_Start_Date, Sch_End_Date);
//             if (!dateValidation.valid) {
//                 return res.status(400).json({
//                     success: false,
//                     message: 'Validation failed',
//                     errors: [{ field: 'Sch_End_Date', message: dateValidation.message }]
//                 });
//             }
//         }

//         // Check for duplicate schedule number
//         const dupCheck = await db.query(
//             `SELECT 1 FROM tbl_Project_Schedule WHERE UPPER(Sch_No) = UPPER(?) AND Sch_Del_Flag = 0`,
//             { replacements: [Sch_No], type: QueryTypes.SELECT }
//         ) as any[];

//         if (dupCheck.length) {
//             return res.status(409).json({
//                 success: false,
//                 message: 'Schedule number already exists'
//             });
//         }

//         // Get next schedule ID
//         const maxIdResult = await db.query(
//             `SELECT ISNULL(MAX(Sch_Id), 0) + 1 as NextId FROM tbl_Project_Schedule`,
//             { type: QueryTypes.SELECT }
//         ) as any[];

//         const nextSchId = maxIdResult[0]?.NextId;
//         if (!nextSchId) throw new Error('Failed to generate next Schedule ID');

//         transaction = await db.transaction();
//         isTransactionActive = true;

//         try {
//             // Insert main schedule record
//             await db.query(
//                 `INSERT INTO tbl_Project_Schedule
//                  (Sch_Id, Sch_No, Sch_Date, Task_Id, Task_Type_Id, Sch_Plan_Id,
//                   Sch_Type,
//                   Sch_Start_Date, Sch_End_Date, Task_Sch_Timer_Based,
//                   Sch_Est_Start_Time, Sch_Est_End_Time, Task_Sch_Duaration,
//                   Sch_Status, Entry_By, Entry_Date, Sch_Del_Flag, Sch_Comp_Date)
//                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE(), 0, ${Sch_Status === 3 ? 'GETDATE()' : 'NULL'})`,
//                 {
//                     replacements: [
//                         nextSchId,
//                         Sch_No,
//                         formatDateForSQL(Sch_Date || new Date()),
//                         Task_Id,
//                         Task_Type_Id,
//                         Sch_Plan_Id,
//                         Sch_Type || 1,
//                         formatDateForSQL(Sch_Start_Date),
//                         formatDateForSQL(Sch_End_Date),
//                         Task_Sch_Timer_Based ? 1 : 0,
//                         Sch_Est_Start_Time,
//                         Sch_Est_End_Time,
//                         Task_Sch_Duaration,
//                         Sch_Status,
//                         Entry_By
//                     ],
//                     type: QueryTypes.INSERT,
//                     transaction
//                 }
//             );

//             // Insert plan detail rows for non-Plan 5 schedules
//             if (Sch_Plan_Id !== 5) {
//                 await insertPlanDetails(db, nextSchId, Sch_Plan_Id, selectedDays || [], planDetails, transaction);
//             }

//             // Generate task work dates
//             let taskDatesToInsert: Date[] = [];

//             if (Sch_Plan_Id === 5) {
//                 // PLAN 5: SPECIFIC DATES - Use ONLY the specificDates array from frontend
//                 console.log('Plan 5 - specificDates from frontend:', specificDates);

//                 if (specificDates && specificDates.length > 0) {
//                     // IMPORTANT: Use ONLY the specificDates array, ignore Sch_Start_Date and Sch_End_Date
//                     taskDatesToInsert = specificDates
//                         .filter(ds => ds && /^\d{4}-\d{2}-\d{2}$/.test(ds))
//                         .map(ds => parseDateString(ds));
//                     console.log(`Plan 5: Using ${taskDatesToInsert.length} specific dates from frontend (IGNORING Sch_Start_Date/Sch_End_Date):`, 
//                         taskDatesToInsert.map(d => formatDateForSQL(d)));
//                 } else {
//                     // Only fallback to Sch_Start_Date if NO specific dates provided at all
//                     if (Sch_Start_Date) {
//                         taskDatesToInsert = [new Date(Sch_Start_Date)];
//                         console.log(`Plan 5: No specific dates provided, falling back to Sch_Start_Date: ${formatDateForSQL(Sch_Start_Date)}`);
//                     } else {
//                         console.warn(`Plan 5: No specific dates and no start date provided - no task dates will be created`);
//                     }
//                 }
//             } 
//             else if (Sch_Start_Date && Sch_End_Date) {
//                 taskDatesToInsert = generateTaskDates(
//                     new Date(Sch_Start_Date), 
//                     new Date(Sch_End_Date),
//                     Sch_Plan_Id, 
//                     selectedDays || [], 
//                     planDetails, 
//                     specificDates || []
//                 );
//                 console.log(`Plan ${Sch_Plan_Id}: Generated ${taskDatesToInsert.length} task dates from range`);
//             }

//             if (taskDatesToInsert.length > 0) {
//                 await insertTaskDates(db, nextSchId, taskDatesToInsert, Sch_Est_Start_Time, Sch_Est_End_Time, transaction);
//                 console.log(`Inserted ${taskDatesToInsert.length} task dates for schedule ${nextSchId}`);
//                 console.log(`Inserted dates:`, taskDatesToInsert.map(d => formatDateForSQL(d)));
//             } else {
//                 console.warn(`No task dates generated for schedule ${nextSchId}`);
//             }

//             await transaction.commit();
//             isTransactionActive = false;
//             transaction = null;

//             // Return the newly created record
//             const data = await db.query(
//                 `SELECT s.*, t.Task_Name, p.Plan_Type, pm.Project_Name, pm.Project_Id
//                  FROM tbl_Project_Schedule s
//                  LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
//                  LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
//                  LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
//                  WHERE s.Sch_Id = ?`,
//                 { replacements: [nextSchId], type: QueryTypes.SELECT }
//             ) as any[];

//             const taskDatesResult = await db.query(
//                 `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`,
//                 { replacements: [nextSchId], type: QueryTypes.SELECT }
//             ) as any[];

//             const planDt = Sch_Plan_Id !== 5 ? await db.query(
//                 `SELECT * FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`,
//                 { replacements: [nextSchId], type: QueryTypes.SELECT }
//             ) as any[] : [];

//             console.log('Final task dates saved to tbl_Project_Sch_Task_DT:', taskDatesResult.map(t => t.Task_Work_Date));
//             console.log('Final schedule saved to tbl_Project_Schedule:', data[0]?.Sch_Id, data[0]?.Sch_No);

//             return created(res, {
//                 ...data[0],
//                 taskDates: taskDatesResult,
//                 planDetails: planDt
//             }, 'Project schedule created successfully');

//         } catch (error) {
//             console.error('Error during transaction operations:', error);
//             if (transaction && isTransactionActive) {
//                 try { await transaction.rollback(); isTransactionActive = false; } catch (e) { console.error('Rollback error:', e); }
//             }
//             throw error;
//         }

//     } catch (e) {
//         console.error('Create Schedule Error:', e);
//         if (transaction && isTransactionActive) {
//             try { await transaction.rollback(); isTransactionActive = false; } catch (err) { console.error('Final rollback error:', err); }
//         }
//         return res.status(500).json({
//             success: false,
//             message: 'Failed to create schedule',
//             error: e instanceof Error ? e.message : 'Unknown error',
//             stack: process.env.NODE_ENV === 'development' ? (e instanceof Error ? e.stack : undefined) : undefined
//         });
//     }
// };


export const createSchedule = async (req: Request, res: Response) => {
    let transaction: Transaction | null = null;
    let isTransactionActive = false;

    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const body = {
            ...req.body,
            Sch_No: req.body.Sch_No?.trim(),
            Sch_Status: req.body.Sch_Status || 1
        };

        const validation = validateWithZod<ScheduleCreate>(ScheduleCreateSchema, body);
        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        const {
            Sch_No,
            Sch_Date,
            Task_Id,
            Task_Type_Id,
            Sch_Plan_Id,
            Sch_Type,
            Task_Sch_Timer_Based,
            Sch_Est_Start_Time,
            Sch_Est_End_Time,
            Task_Sch_Duaration,
            Sch_Status,
            Entry_By,
            planDetails,
            selectedDays,
            specificDates,
            Ticket_Id
        } = validation.data!;

        let Sch_Start_Date = validation.data!.Sch_Start_Date;
        let Sch_End_Date = validation.data!.Sch_End_Date;

        // PLAN 5 => AUTO SET START/END DATE FROM specificDates
        if (Sch_Plan_Id === 5 && specificDates && specificDates.length > 0) {
            const sortedDates = [...specificDates].sort();

            try {
                Sch_Start_Date = parseDateString(sortedDates[0]);
                Sch_End_Date = parseDateString(sortedDates[sortedDates.length - 1]);
            } catch (parseErr) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: [{ field: 'specificDates', message: 'One or more specific dates are invalid' }]
                });
            }

        }

        if (Sch_Plan_Id !== 5) {
            const dateValidation = validateDateRange(Sch_Start_Date, Sch_End_Date);
            if (!dateValidation.valid) {
                return res.status(400).json({
                    success: false,
                    message: 'Validation failed',
                    errors: [{ field: 'Sch_End_Date', message: dateValidation.message }]
                });
            }
        }

        // Duplicate check is removed since Sch_No is auto-generated with a unique ID below

        // Safe defaults so `undefined` never hits the SQL driver
        const safeSchType = Sch_Type ?? 1;
        const safeTimerBased = Task_Sch_Timer_Based ? 1 : 0;
        const safeEstStart = Sch_Est_Start_Time ?? null;
        const safeEstEnd = Sch_Est_End_Time ?? null;
        const safeDuration = Task_Sch_Duaration ?? null;
        const safeEntryBy = Entry_By ?? null;
        let safeTicketId = Ticket_Id ?? (req.body.Ticket_Id ? Number(req.body.Ticket_Id) : null);
        if (!safeTicketId && Sch_No) {
            const m = String(Sch_No).match(/TCK-0*(\d+)/i);
            if (m && m[1]) {
                safeTicketId = Number(m[1]);
            }
        }

        transaction = await db.transaction();
        isTransactionActive = true;

        try {
            // Generate next Schedule ID INSIDE the transaction with a table lock,
            // to avoid two concurrent requests computing the same MAX(Sch_Id)+1.
            const maxIdResult = await db.query(
                `SELECT ISNULL(MAX(Sch_Id), 0) + 1 as NextId
                 FROM tbl_Project_Schedule WITH (TABLOCKX, HOLDLOCK)`,
                { type: QueryTypes.SELECT, transaction }
            ) as any[];

            const nextSchId = maxIdResult[0]?.NextId;
            if (!nextSchId) throw new Error('Failed to generate next Schedule ID');

            // Auto-generate Sch_No: SCH-YYYY-MM-DD-Sch_Id
            const d = Sch_Date ? new Date(Sch_Date) : new Date();
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            const autoSchNo = /TCK-/i.test(String(Sch_No || '')) ? `${String(Sch_No).trim().slice(0, 35)}-${nextSchId}` : `SCH-${y}-${m}-${day}-${nextSchId}`;

            const Sch_First_Start_Date = validation.data!.Sch_First_Start_Date || Sch_Start_Date;
            const Sch_First_End_Date = validation.data!.Sch_First_End_Date || Sch_End_Date;

            // Check if Ticket_Id column exists in tbl_Project_Schedule
            const colCheck = await db.query(
                `SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('tbl_Project_Schedule') AND name = 'Ticket_Id'`,
                { type: QueryTypes.SELECT, transaction }
            ) as any[];
            const hasTicketIdCol = colCheck && colCheck.length > 0;

            if (hasTicketIdCol) {
                await db.query(
                    `INSERT INTO tbl_Project_Schedule
                     (Sch_Id, Sch_No, Sch_Date, Task_Id, Task_Type_Id, Sch_Plan_Id,
                      Sch_Type,
                      Sch_Start_Date, Sch_End_Date, Sch_First_Start_Date, Sch_First_End_Date, Task_Sch_Timer_Based,
                      Sch_Est_Start_Time, Sch_Est_End_Time, Task_Sch_Duaration,
                      Sch_Status, Entry_By, Entry_Date, Sch_Del_Flag, Sch_Comp_Date, Ticket_Id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE(), 0, CASE WHEN ? = 3 THEN GETDATE() ELSE NULL END, ?)`,
                    {
                        replacements: [
                            nextSchId,
                            autoSchNo,
                            formatDateForSQL(Sch_Date || new Date()),
                            Task_Id,
                            Task_Type_Id,
                            Sch_Plan_Id,
                            safeSchType,
                            formatDateForSQL(Sch_Start_Date),
                            formatDateForSQL(Sch_End_Date),
                            formatDateForSQL(Sch_First_Start_Date),
                            formatDateForSQL(Sch_First_End_Date),
                            safeTimerBased,
                            safeEstStart,
                            safeEstEnd,
                            safeDuration,
                            Sch_Status,
                            safeEntryBy,
                            Sch_Status,
                            safeTicketId
                        ],
                        type: QueryTypes.INSERT,
                        transaction
                    }
                );
            } else {
                await db.query(
                    `INSERT INTO tbl_Project_Schedule
                     (Sch_Id, Sch_No, Sch_Date, Task_Id, Task_Type_Id, Sch_Plan_Id,
                      Sch_Type,
                      Sch_Start_Date, Sch_End_Date, Sch_First_Start_Date, Sch_First_End_Date, Task_Sch_Timer_Based,
                      Sch_Est_Start_Time, Sch_Est_End_Time, Task_Sch_Duaration,
                      Sch_Status, Entry_By, Entry_Date, Sch_Del_Flag, Sch_Comp_Date)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, GETDATE(), 0, CASE WHEN ? = 3 THEN GETDATE() ELSE NULL END)`,
                    {
                        replacements: [
                            nextSchId,
                            autoSchNo,
                            formatDateForSQL(Sch_Date || new Date()),
                            Task_Id,
                            Task_Type_Id,
                            Sch_Plan_Id,
                            safeSchType,
                            formatDateForSQL(Sch_Start_Date),
                            formatDateForSQL(Sch_End_Date),
                            formatDateForSQL(Sch_First_Start_Date),
                            formatDateForSQL(Sch_First_End_Date),
                            safeTimerBased,
                            safeEstStart,
                            safeEstEnd,
                            safeDuration,
                            Sch_Status,
                            safeEntryBy,
                            Sch_Status
                        ],
                        type: QueryTypes.INSERT,
                        transaction
                    }
                );
            }

            // Insert plan detail rows for non-Plan 5 schedules
            if (Sch_Plan_Id !== 5) {
                await insertPlanDetails(db, nextSchId, Sch_Plan_Id, selectedDays || [], planDetails, transaction);
            }

            // Generate task work dates
            let taskDatesToInsert: Date[] = [];

            if (Sch_Plan_Id === 5) {

                if (specificDates && specificDates.length > 0) {
                    taskDatesToInsert = specificDates
                        .filter(ds => ds && /^\d{4}-\d{2}-\d{2}$/.test(ds))
                        .map(ds => parseDateString(ds));
                } else if (Sch_Start_Date) {
                    taskDatesToInsert = [new Date(Sch_Start_Date)];
                } else {
                    console.warn(`Plan 5: No specific dates and no start date provided - no task dates will be created`);
                }
            } else if (Sch_Start_Date && Sch_End_Date) {
                taskDatesToInsert = generateTaskDates(
                    new Date(Sch_Start_Date),
                    new Date(Sch_End_Date),
                    Sch_Plan_Id,
                    selectedDays || [],
                    planDetails,
                    specificDates || []
                );
            }

            if (taskDatesToInsert.length > 0) {
                await insertTaskDates(db, nextSchId, taskDatesToInsert, safeEstStart, safeEstEnd, transaction);
            } else {
                console.warn(`No task dates generated for schedule ${nextSchId}`);
            }

            await transaction.commit();
            isTransactionActive = false;
            transaction = null;

            await ensureSchPlanTableSeeded(db);
            await syncTicketScheduleStatuses(db);

            const data = await db.query(
                `SELECT s.*, t.Task_Name,
                        COALESCE(
                            NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                            CASE s.Sch_Plan_Id
                                WHEN 1 THEN 'Time Based'
                                WHEN 2 THEN 'Day Based'
                                WHEN 3 THEN 'Weekly Based'
                                WHEN 4 THEN 'Monthly Based'
                                WHEN 5 THEN 'Specific Day'
                                ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                            END
                        ) as Plan_Type,
                        pm.Project_Name, pm.Project_Id
                 FROM tbl_Project_Schedule s
                 LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
                 LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
                 LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
                 WHERE s.Sch_Id = ?`,
                { replacements: [nextSchId], type: QueryTypes.SELECT }
            ) as any[];

            const taskDatesResult = await db.query(
                `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`,
                { replacements: [nextSchId], type: QueryTypes.SELECT }
            ) as any[];

            const planDt = Sch_Plan_Id !== 5
                ? await db.query(
                    `SELECT * FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`,
                    { replacements: [nextSchId], type: QueryTypes.SELECT }
                ) as any[]
                : [];


            invalidateScheduleCache();

            const createdPlan = resolvePlanTypeName(data[0]?.Plan_Type, data[0]?.Sch_Plan_Id, data[0]?.Sch_Type);
            return created(res, {
                ...data[0],
                Plan_Type: createdPlan,
                planType: createdPlan,
                taskDates: taskDatesResult,
                planDetails: planDt
            }, 'Project schedule created successfully');

        } catch (error) {
            console.error('Error during transaction operations (raw):', error);
            const original = (error as any)?.original ?? (error as any)?.parent;
            console.error('Error during transaction operations (driver detail):', original);

            if (transaction && isTransactionActive) {
                try { await transaction.rollback(); isTransactionActive = false; } catch (e) { console.error('Rollback error:', e); }
            }
            throw error;
        }

    } catch (e) {
        console.error('Create Schedule Error (raw):', e);

        // Sequelize wraps the actual SQL Server/tedious error inside .original or .parent
        const original = (e as any)?.original ?? (e as any)?.parent;
        console.error('Create Schedule Error (driver detail):', original);

        if (transaction && isTransactionActive) {
            try { await transaction.rollback(); isTransactionActive = false; } catch (err) { console.error('Final rollback error:', err); }
        }

        const resolvedMessage =
            (e instanceof Error && e.message) ||
            original?.message ||
            original?.originalError?.info?.message ||
            (original ? JSON.stringify(original) : null) ||
            'Unknown error';

        return res.status(500).json({
            success: false,
            message: 'Failed to create schedule',
            error: resolvedMessage,
            sqlError: original ? {
                number: original.number,
                state: original.state,
                class: original.class,
                lineNumber: original.lineNumber,
                procName: original.procName
            } : undefined,
            stack: process.env.NODE_ENV === 'development' ? (e instanceof Error ? e.stack : undefined) : undefined
        });
    }
};


export const updateSchedule = async (req: Request, res: Response) => {
    let transaction: Transaction | null = null;
    let isTransactionActive = false;

    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const idCheck = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!idCheck.success) {
            return res.status(400).json({ success: false, errors: idCheck.errors });
        }

        const bodyCheck = validateWithZod<ScheduleUpdate>(ScheduleUpdateSchema, req.body);
        if (!bodyCheck.success) {
            return res.status(400).json({ success: false, errors: bodyCheck.errors });
        }

        const scheduleId = idCheck.data!.id;
        const updateData = bodyCheck.data!;

        // PLAN 5 => AUTO UPDATE START/END DATE FROM specificDates
        if (
            updateData.Sch_Plan_Id === 5 &&
            updateData.specificDates &&
            updateData.specificDates.length > 0
        ) {
            const sortedDates = [...updateData.specificDates].sort();

            // Convert string dates to Date objects
            updateData.Sch_Start_Date = parseDateString(sortedDates[0]);
            updateData.Sch_End_Date = parseDateString(sortedDates[sortedDates.length - 1]);

        }

        // Confirm schedule exists and get current status for completion date handling
        const exists = await db.query(
            `SELECT Sch_Plan_Id, Sch_Status, Sch_Start_Date, Sch_End_Date, Task_Sch_Timer_Based, Sch_Est_Start_Time, Sch_Est_End_Time, Task_Sch_Duaration, Sch_Type 
             FROM tbl_Project_Schedule WHERE Sch_Id = ? AND Sch_Del_Flag = 0`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        if (!exists.length) return notFound(res, 'Project schedule not found');

        const currentPlanId = exists[0].Sch_Plan_Id;
        const currentStatus = exists[0].Sch_Status;

        // Check for duplicate schedule number
        if (updateData.Sch_No) {
            const dupCheck = await db.query(
                `SELECT 1 FROM tbl_Project_Schedule
                 WHERE UPPER(Sch_No) = UPPER(?) AND Sch_Id != ? AND Sch_Del_Flag = 0`,
                { replacements: [updateData.Sch_No, scheduleId], type: QueryTypes.SELECT }
            ) as any[];

            if (dupCheck.length) {
                return res.status(409).json({
                    success: false,
                    message: 'Schedule number already exists'
                });
            }
        }

        transaction = await db.transaction();
        isTransactionActive = true;

        try {
            // Build dynamic UPDATE
            const updateFields: string[] = [];
            const updateValues: any[] = [];

            if (updateData.Sch_No !== undefined) { updateFields.push('Sch_No = ?'); updateValues.push(updateData.Sch_No); }
            if (updateData.Sch_Date !== undefined) { updateFields.push('Sch_Date = ?'); updateValues.push(formatDateForSQL(updateData.Sch_Date)); }
            if (updateData.Task_Id !== undefined) { updateFields.push('Task_Id = ?'); updateValues.push(updateData.Task_Id); }
            if (updateData.Task_Type_Id !== undefined) { updateFields.push('Task_Type_Id = ?'); updateValues.push(updateData.Task_Type_Id); }
            if (updateData.Sch_Plan_Id !== undefined) { updateFields.push('Sch_Plan_Id = ?'); updateValues.push(updateData.Sch_Plan_Id); }
            if (updateData.Sch_Type !== undefined) { updateFields.push('Sch_Type = ?'); updateValues.push(updateData.Sch_Type); }
            if (updateData.Sch_Start_Date !== undefined) {
                updateFields.push('Sch_Start_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_Start_Date));
            }
            if (updateData.Sch_First_Start_Date !== undefined) {
                updateFields.push('Sch_First_Start_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_First_Start_Date));
            } else if (updateData.Sch_Start_Date !== undefined && !(updateData as any).isExtension) {
                updateFields.push('Sch_First_Start_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_Start_Date));
            }

            if (updateData.Sch_End_Date !== undefined) {
                updateFields.push('Sch_End_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_End_Date));
            }
            if (updateData.Sch_First_End_Date !== undefined) {
                updateFields.push('Sch_First_End_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_First_End_Date));
            } else if (updateData.Sch_End_Date !== undefined && !(updateData as any).isExtension) {
                updateFields.push('Sch_First_End_Date = ?');
                updateValues.push(formatDateForSQL(updateData.Sch_End_Date));
            }
            if (updateData.Task_Sch_Timer_Based !== undefined) { updateFields.push('Task_Sch_Timer_Based = ?'); updateValues.push(updateData.Task_Sch_Timer_Based ? 1 : 0); }
            if (updateData.Sch_Est_Start_Time !== undefined) { updateFields.push('Sch_Est_Start_Time = ?'); updateValues.push(updateData.Sch_Est_Start_Time); }
            if (updateData.Sch_Est_End_Time !== undefined) { updateFields.push('Sch_Est_End_Time = ?'); updateValues.push(updateData.Sch_Est_End_Time); }
            if (updateData.Task_Sch_Duaration !== undefined) { updateFields.push('Task_Sch_Duaration = ?'); updateValues.push(updateData.Task_Sch_Duaration); }

            // Handle Sch_Status with completion date logic
            if (updateData.Sch_Status !== undefined) {
                updateFields.push('Sch_Status = ?');
                updateValues.push(updateData.Sch_Status);

                // If setting status to 3 (completed), set completion date
                if (updateData.Sch_Status === 3) {
                    updateFields.push('Sch_Comp_Date = GETDATE()');
                }
                // If changing from completed to another status, clear completion date
                else if (currentStatus === 3 && updateData.Sch_Status !== 3) {
                    updateFields.push('Sch_Comp_Date = NULL');
                }
            }

            if (updateData.Update_By !== undefined) { updateFields.push('Update_By = ?'); updateValues.push(updateData.Update_By); }

            const ticketIdToUpdate = updateData.Ticket_Id !== undefined ? updateData.Ticket_Id : (req.body as any).Ticket_Id;
            if (ticketIdToUpdate !== undefined) {
                const colCheck = await db.query(
                    `SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('tbl_Project_Schedule') AND name = 'Ticket_Id'`,
                    { type: QueryTypes.SELECT, transaction }
                ) as any[];
                if (colCheck && colCheck.length > 0) {
                    updateFields.push('Ticket_Id = ?');
                    updateValues.push(ticketIdToUpdate ? Number(ticketIdToUpdate) : null);
                }
            }

            updateFields.push('Update_Date = GETDATE()');

            const getCurrentValue = async (field: string): Promise<any> => {
                const result = await db.query(
                    `SELECT ${field} FROM tbl_Project_Schedule WHERE Sch_Id = ?`,
                    { replacements: [scheduleId], type: QueryTypes.SELECT, transaction }
                ) as any[];
                return result[0]?.[field];
            };

            // Fetch OLD values BEFORE updating if this is an extension
            let oldStartDate, oldEndDate, timerBased, estStart, estEnd, duration, schType;
            if ((updateData as any).isExtension) {
                oldStartDate = await getCurrentValue('Sch_Start_Date');
                oldEndDate = await getCurrentValue('Sch_End_Date');
                timerBased = await getCurrentValue('Task_Sch_Timer_Based');
                estStart = await getCurrentValue('Sch_Est_Start_Time');
                estEnd = await getCurrentValue('Sch_Est_End_Time');
                duration = await getCurrentValue('Task_Sch_Duaration');
                schType = await getCurrentValue('Sch_Type');
            }

            if (updateFields.length > 0) {
                updateValues.push(scheduleId);
                await db.query(
                    `UPDATE tbl_Project_Schedule SET ${updateFields.join(', ')} WHERE Sch_Id = ?`,
                    { replacements: updateValues, transaction }
                );
            }

            // --- Extension Logic ---
            if ((updateData as any).isExtension) {
                const extStartDate = updateData.Sch_Start_Date !== undefined ? updateData.Sch_Start_Date : oldStartDate;
                const extEndDate = updateData.Sch_End_Date !== undefined ? updateData.Sch_End_Date : oldEndDate;
                const extTimerBased = updateData.Task_Sch_Timer_Based !== undefined ? updateData.Task_Sch_Timer_Based : timerBased;
                const extEstStart = updateData.Sch_Est_Start_Time !== undefined ? updateData.Sch_Est_Start_Time : estStart;
                const extEstEnd = updateData.Sch_Est_End_Time !== undefined ? updateData.Sch_Est_End_Time : estEnd;
                const extDuration = updateData.Task_Sch_Duaration !== undefined ? updateData.Task_Sch_Duaration : duration;
                const extSchType = updateData.Sch_Type !== undefined ? updateData.Sch_Type : schType;

                await db.query(
                    `INSERT INTO tbl_Project_Schedule_Extend
                     (Sch_Id, Sch_EX_Start_Date, Sch_EX_End_Date, Task_Sch_Timer_Based,
                      Sch_Est_Start_Time, Sch_Est_End_Time, Task_Sch_Duaration, Sch_Type)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    {
                        replacements: [
                            scheduleId,
                            extStartDate ? formatDateForSQL(extStartDate) : null,
                            extEndDate ? formatDateForSQL(extEndDate) : null,
                            extTimerBased ? 1 : 0,
                            extEstStart ?? null,
                            extEstEnd ?? null,
                            extDuration ?? null,
                            extSchType ?? null
                        ],
                        transaction
                    }
                );
            }

            const isExtension = (updateData as any).isExtension === true;
            
            // Regenerate task dates whenever the configuration changes
            const shouldRegenerate = isExtension ||
                updateData.Sch_Plan_Id !== undefined ||
                updateData.Sch_Start_Date !== undefined ||
                updateData.Sch_End_Date !== undefined ||
                updateData.selectedDays !== undefined ||
                updateData.specificDates !== undefined;

            if (shouldRegenerate) {
                // Fetch existing employee assignments so we can carry them over
                const existingEmployees = await db.query(
                    `SELECT DISTINCT Emp_Id, Project_Id, Task_Levl_Id, Task_Id, Assigned_Emp_Id, Ord_By, Invovled_Stat 
                     FROM tbl_Task_Details WHERE Sch_Id = ?`,
                    { replacements: [scheduleId], type: QueryTypes.SELECT, transaction }
                ) as any[];

                // Delete existing schedule config detail rows
                await db.query(`DELETE FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`, { replacements: [scheduleId], transaction });
                await db.query(`DELETE FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ?`, { replacements: [scheduleId], transaction });
                
                // Delete tbl_Task_Details entirely because we regenerate them for all new dates
                await db.query(`DELETE FROM tbl_Task_Details WHERE Sch_Id = ?`, { replacements: [scheduleId], transaction });

                const planId = updateData.Sch_Plan_Id !== undefined ? updateData.Sch_Plan_Id : currentPlanId;
                const startDate = updateData.Sch_Start_Date !== undefined ? updateData.Sch_Start_Date : await getCurrentValue('Sch_Start_Date');
                const endDate = updateData.Sch_End_Date !== undefined ? updateData.Sch_End_Date : await getCurrentValue('Sch_End_Date');
                const selectedDaysArray = updateData.selectedDays || [];
                const specificDatesArray = updateData.specificDates || [];
                const estStartTime = updateData.Sch_Est_Start_Time !== undefined ? updateData.Sch_Est_Start_Time : await getCurrentValue('Sch_Est_Start_Time');
                const estEndTime = updateData.Sch_Est_End_Time !== undefined ? updateData.Sch_Est_End_Time : await getCurrentValue('Sch_Est_End_Time');

                // Re-insert plan detail rows for non-Plan 5
                if (planId !== 5) {
                    await insertPlanDetails(db, scheduleId, planId, selectedDaysArray, updateData.planDetails, transaction);
                }

                // Regenerate task work dates
                let taskDatesToInsert: Date[] = [];

                if (!isExtension && specificDatesArray.length > 0) {
                    // Correction - Use ONLY specificDates array from frontend
                    taskDatesToInsert = specificDatesArray
                        .filter((ds: string) => ds && /^\d{4}-\d{2}-\d{2}$/.test(ds))
                        .map((ds: string) => parseDateString(ds));
                } else if (planId === 5) {
                    // PLAN 5: SPECIFIC DATES - Use ONLY specificDates array
                    if (specificDatesArray.length > 0) {
                        taskDatesToInsert = specificDatesArray
                            .filter((ds: string) => ds && /^\d{4}-\d{2}-\d{2}$/.test(ds))
                            .map((ds: string) => parseDateString(ds));
                    } else if (startDate) {
                        taskDatesToInsert = [new Date(startDate)];
                    }
                } else if (startDate && endDate) {
                    taskDatesToInsert = generateTaskDates(
                        new Date(startDate),
                        new Date(endDate),
                        planId,
                        selectedDaysArray,
                        updateData.planDetails,
                        []
                    );
                }

                if (taskDatesToInsert.length > 0) {
                    await insertTaskDates(db, scheduleId, taskDatesToInsert, estStartTime, estEndTime, transaction);

                    if (existingEmployees.length > 0) {
                        const anNoRes = await db.query(
                            `SELECT ISNULL(MAX(AN_No), 0) AS maxANNo FROM tbl_Task_Details`,
                            { type: QueryTypes.SELECT, transaction }
                        ) as any[];
                        let nextANNo = (anNoRes[0]?.maxANNo || 0);

                        for (const emp of existingEmployees) {
                            for (const tDate of taskDatesToInsert) {
                                nextANNo++;
                                await db.query(
                                    `INSERT INTO tbl_Task_Details
                                     (AN_No, Project_Id, Sch_Id, Task_Levl_Id, Task_Id, Assigned_Emp_Id, Emp_Id, 
                                      Task_Assign_dt, Sch_Time, EN_Time, Ord_By, Invovled_Stat)
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                    {
                                        replacements: [
                                            nextANNo, emp.Project_Id, scheduleId, emp.Task_Levl_Id, emp.Task_Id,
                                            emp.Assigned_Emp_Id, emp.Emp_Id, formatDateForSQL(tDate),
                                            estStartTime, estEndTime, emp.Ord_By, emp.Invovled_Stat
                                        ],
                                        type: QueryTypes.INSERT,
                                        transaction
                                    }
                                );
                            }
                        }
                    }
                } else {
                    // No dates generated, delete all assignments
                    await db.query(`DELETE FROM tbl_Task_Details WHERE Sch_Id = ?`, { replacements: [scheduleId], transaction });
                }
            }

            await transaction.commit();
            isTransactionActive = false;
            transaction = null;

            await ensureSchPlanTableSeeded(db);

            // Return the updated record
            const data = await db.query(
                `SELECT s.*, t.Task_Name,
                        COALESCE(
                            NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                            CASE s.Sch_Plan_Id
                                WHEN 1 THEN 'Time Based'
                                WHEN 2 THEN 'Day Based'
                                WHEN 3 THEN 'Weekly Based'
                                WHEN 4 THEN 'Monthly Based'
                                WHEN 5 THEN 'Specific Day'
                                ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                            END
                        ) as Plan_Type,
                        pm.Project_Name, pm.Project_Id
                 FROM tbl_Project_Schedule s
                 LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
                 LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
                 LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
                 WHERE s.Sch_Id = ?`,
                { replacements: [scheduleId], type: QueryTypes.SELECT }
            ) as any[];

            const taskDatesResult = await db.query(
                `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`,
                { replacements: [scheduleId], type: QueryTypes.SELECT }
            ) as any[];

            const planDt = await db.query(
                `SELECT * FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`,
                { replacements: [scheduleId], type: QueryTypes.SELECT }
            ) as any[];

            invalidateScheduleCache();

            const updatedPlan = resolvePlanTypeName(data[0]?.Plan_Type, data[0]?.Sch_Plan_Id, data[0]?.Sch_Type);
            return updated(res, { ...data[0], Plan_Type: updatedPlan, planType: updatedPlan, taskDates: taskDatesResult, planDetails: planDt }, 'Project schedule updated successfully');

        } catch (error) {
            console.error('Error during transaction operations:', error);
            if (transaction && isTransactionActive) {
                try { await transaction.rollback(); isTransactionActive = false; } catch (e) { console.error('Rollback error:', e); }
            }
            throw error;
        }

    } catch (e: any) {
        console.error('Update Schedule Error:', e);
        if (transaction && isTransactionActive) {
            try { await transaction.rollback(); isTransactionActive = false; } catch (err) { console.error('Final rollback error:', err); }
        }

        const sqlErrorMsg = e?.original?.message || e?.parent?.message || e?.message || 'Unknown error';

        return res.status(500).json({
            success: false,
            message: `Failed to update schedule: ${sqlErrorMsg}`,
            error: sqlErrorMsg,
            stack: process.env.NODE_ENV === 'development' ? (e instanceof Error ? e.stack : undefined) : undefined
        });
    }
};

export const updateScheduleStatus = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const idCheck = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!idCheck.success) {
            return res.status(400).json({ success: false, errors: idCheck.errors });
        }

        const bodyCheck = validateWithZod<ScheduleStatusUpdate>(ScheduleStatusUpdateSchema, req.body);
        if (!bodyCheck.success) {
            return res.status(400).json({ success: false, errors: bodyCheck.errors });
        }

        const status = bodyCheck.data!.status;
        const updateBy = bodyCheck.data!.Update_By;
        const scheduleId = idCheck.data!.id;

        // Get current status to determine if completion date should be cleared
        const currentRecord = await db.query(
            `SELECT Sch_Status FROM tbl_Project_Schedule WHERE Sch_Id = ? AND Sch_Del_Flag = 0`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        const currentStatus = currentRecord[0]?.Sch_Status;

        // Build the update query with completion date logic
        let compDateUpdate = '';
        if (status === 3) {
            // Setting to completed
            compDateUpdate = ', Sch_Comp_Date = GETDATE()';
        } else if (currentStatus === 3 && status !== 3) {
            // Changing from completed to another status
            compDateUpdate = ', Sch_Comp_Date = NULL';
        }

        await db.query(
            `UPDATE tbl_Project_Schedule 
             SET Sch_Status = ?, 
                 Update_By = ?, 
                 Update_Date = GETDATE()
                 ${compDateUpdate}
             WHERE Sch_Id = ? AND Sch_Del_Flag = 0`,
            { replacements: [status, updateBy, scheduleId] }
        );

        await ensureSchPlanTableSeeded(db);

        // Fetch updated record to return
        const updatedRecord = await db.query(
            `SELECT s.*, t.Task_Name,
                    COALESCE(
                        NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                        CASE s.Sch_Plan_Id
                            WHEN 1 THEN 'Time Based'
                            WHEN 2 THEN 'Day Based'
                            WHEN 3 THEN 'Weekly Based'
                            WHEN 4 THEN 'Monthly Based'
                            WHEN 5 THEN 'Specific Day'
                            ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                        END
                    ) as Plan_Type,
                    pm.Project_Name, pm.Project_Id
             FROM tbl_Project_Schedule s
             LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
             LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
             LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
             WHERE s.Sch_Id = ? AND s.Sch_Del_Flag = 0`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        // Also fetch task dates if needed
        const taskDatesResult = await db.query(
            `SELECT * FROM tbl_Project_Sch_Task_DT WHERE Sch_Id = ? ORDER BY Task_Work_Date`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        const planDt = await db.query(
            `SELECT * FROM tbl_Project_Sch_DT WHERE Sch_Id = ?`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        const statusPlan = updatedRecord[0]
            ? resolvePlanTypeName(updatedRecord[0].Plan_Type, updatedRecord[0].Sch_Plan_Id, updatedRecord[0].Sch_Type)
            : '';
        const responseData = updatedRecord[0] ? {
            ...updatedRecord[0],
            Plan_Type: statusPlan,
            planType: statusPlan,
            taskDates: taskDatesResult,
            planDetails: planDt
        } : null;

        invalidateScheduleCache();

        updated(res, responseData, 'Schedule status updated successfully');
    } catch (e) {
        console.error('Error in updateScheduleStatus:', e);
        servError(e, res);
    }
};

export const deleteSchedule = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const validation = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!validation.success) {
            return res.status(400).json({ success: false, errors: validation.errors });
        }

        await db.query(
            `UPDATE tbl_Project_Schedule SET Sch_Del_Flag = 1, Update_Date = GETDATE()
             WHERE Sch_Id = ? AND Sch_Del_Flag = 0`,
            { replacements: [validation.data!.id] }
        );

        invalidateScheduleCache();

        deleted(res, 'Project schedule deleted successfully');
    } catch (e) {
        console.error('Error in deleteSchedule:', e);
        servError(e, res);
    }
};

export const getSchedulePlansDropdown = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        await ensureSchPlanTableSeeded(db);

        let rows: any[] = [];
        try {
            rows = await db.query(
                `SELECT Plan_Id as value, Plan_Type as label FROM tbl_Sch_Plan ORDER BY Plan_Id`,
                { type: QueryTypes.SELECT }
            ) as any[];
        } catch (dbErr: any) {
            console.warn('⚠️ getSchedulePlansDropdown table query warning, using defaults:', dbErr.message);
        }

        const mergedMap = new Map<number, { value: number; label: string }>();
        for (const def of DEFAULT_SCHEDULE_PLANS) {
            mergedMap.set(def.value, { ...def });
        }
        for (const row of rows || []) {
            const val = Number(row?.value ?? row?.Plan_Id);
            const lbl = typeof (row?.label ?? row?.Plan_Type) === 'string'
                ? String(row?.label ?? row?.Plan_Type).trim()
                : '';
            if (val > 0 && lbl) {
                mergedMap.set(val, { value: val, label: lbl });
            }
        }

        const finalPlans = Array.from(mergedMap.values()).sort((a, b) => a.value - b.value);
        sentData(res, finalPlans);
    } catch (e) {
        console.error('Error in getSchedulePlansDropdown:', e);
        sentData(res, DEFAULT_SCHEDULE_PLANS);
    }
};

export const getTasksDropdown = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const rows = await db.query(
            `SELECT Task_Id as value, Task_Name as label FROM tbl_Task ORDER BY Task_Name`,
            { type: QueryTypes.SELECT }
        ) as any[];

        sentData(res, rows);
    } catch (e) {
        console.error('Error in getTasksDropdown:', e);
        servError(e, res);
    }
};

export const getScheduleTypesDropdown = async (req: Request, res: Response) => {
    try {
        const scheduleTypes = [
            { value: 1, label: 'Special' },
            { value: 2, label: 'Day' },
            { value: 3, label: 'Week' },
            { value: 4, label: 'Month' }
        ];
        sentData(res, scheduleTypes);
    } catch (e) {
        console.error('Error in getScheduleTypesDropdown:', e);
        servError(e, res);
    }
};

export const getScheduleDropdown = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const rows = await db.query(
            `SELECT s.Sch_Id as value, s.Sch_No + ' - ' + ISNULL(t.Task_Name, 'No Task') as label
             FROM tbl_Project_Schedule s
             LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
             WHERE s.Sch_Del_Flag = 0
             ORDER BY s.Sch_No DESC`,
            { type: QueryTypes.SELECT }
        ) as any[];

        sentData(res, rows);
    } catch (e) {
        console.error('Error in getScheduleDropdown:', e);
        servError(e, res);
    }
};

export const getAllActiveSchedules = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        await ensureSchPlanTableSeeded(db);
        await syncTicketScheduleStatuses(db);

        const rows = await db.query(
            `WITH ExtensionCounts AS (
                SELECT Sch_Id, COUNT(*) as extCount
                FROM tbl_Project_Schedule_Extend
                GROUP BY Sch_Id
             )
             SELECT s.*, t.Task_Name,
                    COALESCE(
                        NULLIF(LTRIM(RTRIM(p.Plan_Type)), ''),
                        CASE s.Sch_Plan_Id
                            WHEN 1 THEN 'Time Based'
                            WHEN 2 THEN 'Day Based'
                            WHEN 3 THEN 'Weekly Based'
                            WHEN 4 THEN 'Monthly Based'
                            WHEN 5 THEN 'Specific Day'
                            ELSE CASE WHEN s.Sch_Type = 1 THEN 'Specific Day' WHEN s.Sch_Type = 2 THEN 'Time Based' ELSE 'Time Based' END
                        END
                    ) as Plan_Type,
                    pm.Project_Name, pm.Project_Id,
                    CASE WHEN COALESCE(ec.extCount, 0) > 0 THEN 1 ELSE 0 END as hasExtension
             FROM tbl_Project_Schedule s
             LEFT JOIN tbl_Task t ON s.Task_Id = t.Task_Id
             LEFT JOIN tbl_Project_Master pm ON t.Project_Id = pm.Project_Id
             LEFT JOIN tbl_Sch_Plan p ON s.Sch_Plan_Id = p.Plan_Id
             LEFT JOIN ExtensionCounts ec ON s.Sch_Id = ec.Sch_Id
             WHERE s.Sch_Del_Flag = 0 AND s.Sch_Status = 1
             ORDER BY s.Sch_Date DESC`,
            { type: QueryTypes.SELECT }
        ) as any[];

        const normalizedRows = (rows || []).map((r: any) => {
            const resolvedPlan = resolvePlanTypeName(r.Plan_Type, r.Sch_Plan_Id, r.Sch_Type);
            return {
                ...r,
                Plan_Type: resolvedPlan,
                planType: resolvedPlan
            };
        });

        sentData(res, normalizedRows);
    } catch (e) {
        console.error('Error in getAllActiveSchedules:', e);
        servError(e, res);
    }
};

export const getExtensionsByScheduleId = async (req: Request, res: Response) => {
    try {
        const db = getDb(req);
        const currentDBName = getCurrentDatabaseName(req);

        const idCheck = validateWithZod<{ id: number }>(ScheduleIdSchema, req.params);
        if (!idCheck.success) {
            return res.status(400).json({ success: false, errors: idCheck.errors });
        }

        const scheduleId = idCheck.data!.id;

        const rows = await db.query(
            `SELECT * FROM tbl_Project_Schedule_Extend WHERE Sch_Id = ?`,
            { replacements: [scheduleId], type: QueryTypes.SELECT }
        ) as any[];

        const finalRows: any[] = [];
        for (let r of rows) {
            const row = { ...r };
            // Case-insensitive key lookup
            const keys = Object.keys(row);
            const getVal = (keyName: string) => {
                const k = keys.find(x => x.toLowerCase() === keyName.toLowerCase());
                return k ? row[k] : null;
            };

            const startDate = getVal('Sch_EX_Start_Date');
            const endDate = getVal('Sch_EX_End_Date');

            try {
                const emps = await db.query(
                    `SELECT DISTINCT e.Emp_First_Name
                     FROM tbl_Task_Details td
                     JOIN tbl_Employee_Master e ON td.Emp_Id = e.Emp_Id
                     WHERE td.Sch_Id = ? AND CAST(td.Task_Assign_dt AS DATE) >= CAST(? AS DATE) AND CAST(td.Task_Assign_dt AS DATE) <= CAST(? AS DATE)`,
                     { replacements: [scheduleId, startDate, endDate], type: QueryTypes.SELECT }
                ) as any[];
                row.Employee_Names = emps.map(e => (e.Emp_First_Name || e.emp_first_name)).filter(Boolean).join(', ') || '-';
            } catch (err: any) {
                console.error("Employee lookup failed:", err.message);
                row.Employee_Names = "Lookup Failed";
            }
            finalRows.push(row);
        }

        sentData(res, finalRows);
    } catch (e) {
        console.error('Error in getExtensionsByScheduleId:', e);
        servError(e, res);
    }
};
