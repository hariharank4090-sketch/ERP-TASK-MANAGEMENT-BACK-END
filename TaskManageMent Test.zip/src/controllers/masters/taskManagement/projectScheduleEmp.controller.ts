import { Request, Response } from 'express';
import { Op, Sequelize } from 'sequelize';
import { ZodError } from 'zod';
import { updated, notFound } from '../../../responseObject';
import { initTaskDetailModel, TaskDetailWithSchedule, TaskDetailCreateInput, TaskDetailUpdateInput, TaskDetailQueryParams, taskDetailQuerySchema, taskDetailIdSchema, taskDetailUpdateSchema, taskDetailCreateSchema } from '../../../models/taskDetails/type.model';

// Define interface for schedule task data
interface ScheduleTaskData {
    Task_Work_Date: Date;
    Task_Start_Time: Date;
    Task_End_Time: Date;
}

function parseIdParam(param: string | string[] | undefined): number | null {
    if (!param || Array.isArray(param)) return null;
    const parsed = parseInt(param);
    return isNaN(parsed) ? null : parsed;
}

function getStringParam(param: string | string[] | undefined): string | undefined {
    if (!param) return undefined;
    return Array.isArray(param) ? param[0] : param;
}

const validateWithZod = <T>(schema: any, data: any): {
    success: boolean;
    data?: T;
    errors?: Array<{ field: string; message: string }>
} => {
    try {
        const validatedData = schema.parse(data);
        return { success: true, data: validatedData };
    } catch (error: any) {
        if (error instanceof ZodError) {
            const issues = error.issues;
            return {
                success: false,
                errors: issues.map((err: any) => ({
                    field: err.path.join('.'),
                    message: err.message
                }))
            };
        }
        return {
            success: false,
            errors: [{ field: 'unknown', message: error.message || 'Validation failed' }]
        };
    }
};

// Helper function to convert raw query results to model format
function mapRawToTaskDetail(raw: any): TaskDetailWithSchedule {
    if (!raw) return {} as TaskDetailWithSchedule;

    return {
        Id: raw.Id,
        AN_No: raw.AN_No,
        Project_Id: raw.Project_Id,
        Sch_Id: raw.Sch_Id,
        Task_Levl_Id: raw.Task_Levl_Id,
        Task_Id: raw.Task_Id,
        Assigned_Emp_Id: raw.Assigned_Emp_Id,
        Emp_Id: raw.Emp_Id,
        Task_Assign_dt: raw.Task_Assign_dt,
        Sch_Period: raw.Sch_Period,
        Sch_Time: raw.Sch_Time,
        EN_Time: raw.EN_Time,
        Ord_By: raw.Ord_By,
        Invovled_Stat: raw.Invovled_Stat,
        Schedule_Task_Sch_Timer_Based: raw.Schedule_Task_Sch_Timer_Based,
        Schedule_Sch_No: raw.Schedule_Sch_No,
        Schedule_Sch_Date: raw.Schedule_Sch_Date,
        Schedule_Task_Type_Id: raw.Schedule_Task_Type_Id,
        Schedule_Sch_Plan_Id: raw.Schedule_Sch_Plan_Id,
        Schedule_Sch_Start_Date: raw.Schedule_Sch_Start_Date,
        Schedule_Sch_End_Date: raw.Schedule_Sch_End_Date,
        Schedule_Task_Sch_Duaration: raw.Schedule_Task_Sch_Duaration,
        Schedule_Sch_Status: raw.Schedule_Sch_Status,
        Schedule_Sch_Comp_Date: raw.Schedule_Sch_Comp_Date,
        Schedule_Update_Date: raw.Schedule_Update_Date,
        Schedule_Ticket_Id: raw.Schedule_Ticket_Id || raw.Ticket_Id,
        Ticket_Id: raw.Schedule_Ticket_Id || raw.Ticket_Id,
        Task_Name: raw.Task_Name,
        Task_Desc: raw.Task_Desc,
        Task_Type_Id: raw.Task_Type_Id
    };
}

// Helper to get company database from request
const getCompanyDB = (req: Request): Sequelize => {
    return (req as any).companyDB || (req as any).sequelize;
};

// Helper to get TaskDetail model for specific database
const getTaskDetailModel = (sequelizeInstance: Sequelize) => {
    return initTaskDetailModel(sequelizeInstance);
};

// In-memory cache for getAllTaskDetails
interface TaskDetailCacheEntry {
    data: any[];
    expiry: number;
}
const taskDetailListCache = new Map<string, TaskDetailCacheEntry>();
const TASK_DETAIL_CACHE_TTL = 5000; // 5 seconds cache

export const invalidateTaskDetailCache = () => {
    taskDetailListCache.clear();
};

export const getAllTaskDetails = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const validation = validateWithZod<TaskDetailQueryParams>(taskDetailQuerySchema, req.query);

        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        const currentDBName = (req as any).currentDBName || 'default';
        const cacheKey = `${currentDBName}_taskdetails_${JSON.stringify(req.query)}`;
        const cached = taskDetailListCache.get(cacheKey);
        if (cached && Date.now() < cached.expiry) {
            return res.status(200).json({
                success: true,
                message: 'Task details retrieved successfully',
                data: cached.data
            });
        }

        const {
            Project_Id,
            Sch_Id,
            Task_Id,
            Emp_Id,
            Assigned_Emp_Id,
            Invovled_Stat,
            from_Task_Assign_dt,
            to_Task_Assign_dt,
            sortBy = 'td.Id',
            sortOrder = 'DESC'
        } = validation.data!;

        // Check optional columns on tbl_Project_Schedule to avoid invalid column errors across tenant DBs
        const scheduleCols: any[] = await companyDB.query(
            `SELECT name FROM sys.columns 
             WHERE object_id = OBJECT_ID('tbl_Project_Schedule') 
               AND name IN ('Ticket_Id', 'Sch_Comp_Date', 'Update_Date')`,
            { type: 'SELECT' }
        );
        const scheduleColSet = new Set((scheduleCols || []).map((c: any) => String(c.name).toLowerCase()));
        const hasTicketIdCol = scheduleColSet.has('ticket_id');
        const hasSchCompDateCol = scheduleColSet.has('sch_comp_date');
        const hasUpdateDateCol = scheduleColSet.has('update_date');

        const outerApplyExtraCols = [
            hasSchCompDateCol ? 'ps2.Sch_Comp_Date' : null,
            hasUpdateDateCol ? 'ps2.Update_Date' : null,
            hasTicketIdCol ? 'ps2.Ticket_Id' : null
        ].filter(Boolean).join(', ');

        // Build WHERE conditions
        let whereClause = '1=1';
        const replacements: any = {};

        if (Project_Id) {
            whereClause += ' AND td.Project_Id = :Project_Id';
            replacements.Project_Id = Project_Id;
        }
        if (Sch_Id) {
            whereClause += ' AND td.Sch_Id = :Sch_Id';
            replacements.Sch_Id = Sch_Id;
        }
        if (Task_Id) {
            whereClause += ' AND td.Task_Id = :Task_Id';
            replacements.Task_Id = Task_Id;
        }
        if (Emp_Id) {
            whereClause += ' AND td.Emp_Id = :Emp_Id';
            replacements.Emp_Id = Emp_Id;
        }
        if (Assigned_Emp_Id) {
            whereClause += ' AND td.Assigned_Emp_Id = :Assigned_Emp_Id';
            replacements.Assigned_Emp_Id = Assigned_Emp_Id;
        }
        if (Invovled_Stat !== undefined && Invovled_Stat !== null) {
            whereClause += ' AND td.Invovled_Stat = :Invovled_Stat';
            replacements.Invovled_Stat = Invovled_Stat;
        }
        if (from_Task_Assign_dt && to_Task_Assign_dt) {
            const startDate = new Date(from_Task_Assign_dt);
            startDate.setHours(0, 0, 0, 0);
            const endDate = new Date(to_Task_Assign_dt);
            endDate.setHours(23, 59, 59, 999);
            whereClause += ` AND td.Task_Assign_dt <= :to_Task_Assign_dt AND (
                td.Task_Assign_dt >= :from_Task_Assign_dt 
                OR COALESCE(ps.Sch_Status, latest_ps.Sch_Status, 1) != 3
                ${hasSchCompDateCol ? 'OR CAST(COALESCE(ps.Sch_Comp_Date, latest_ps.Sch_Comp_Date) AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)' : ''}
                ${hasUpdateDateCol ? 'OR CAST(COALESCE(ps.Update_Date, latest_ps.Update_Date) AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)' : ''}
                ${hasTicketIdCol ? 'OR ps.Ticket_Id IS NOT NULL OR latest_ps.Ticket_Id IS NOT NULL' : ''}
                OR ps.Sch_No LIKE 'TCK-%'
                OR latest_ps.Sch_No LIKE 'TCK-%'
                OR ps.Sch_No LIKE 'SCH-%'
                OR latest_ps.Sch_No LIKE 'SCH-%'
                OR EXISTS (
                    SELECT 1 FROM tbl_Work_Master wm WITH (NOLOCK) 
                    WHERE (wm.Sch_Id = td.Sch_Id OR (td.Sch_Id IS NULL AND wm.Task_Id = td.Task_Id))
                      AND wm.Emp_Id = td.Emp_Id 
                      AND CAST(wm.Work_Dt AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)
                      AND CAST(wm.Work_Dt AS DATE) <= CAST(:to_Task_Assign_dt AS DATE)
                )
            )`;
            replacements.from_Task_Assign_dt = startDate;
            replacements.to_Task_Assign_dt = endDate;
        } else if (from_Task_Assign_dt) {
            const startDate = new Date(from_Task_Assign_dt);
            startDate.setHours(0, 0, 0, 0);
            whereClause += ` AND (
                td.Task_Assign_dt >= :from_Task_Assign_dt 
                OR COALESCE(ps.Sch_Status, latest_ps.Sch_Status, 1) != 3
                ${hasSchCompDateCol ? 'OR CAST(COALESCE(ps.Sch_Comp_Date, latest_ps.Sch_Comp_Date) AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)' : ''}
                ${hasUpdateDateCol ? 'OR CAST(COALESCE(ps.Update_Date, latest_ps.Update_Date) AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)' : ''}
                ${hasTicketIdCol ? 'OR ps.Ticket_Id IS NOT NULL OR latest_ps.Ticket_Id IS NOT NULL' : ''}
                OR ps.Sch_No LIKE 'TCK-%'
                OR latest_ps.Sch_No LIKE 'TCK-%'
                OR ps.Sch_No LIKE 'SCH-%'
                OR latest_ps.Sch_No LIKE 'SCH-%'
                OR EXISTS (
                    SELECT 1 FROM tbl_Work_Master wm WITH (NOLOCK) 
                    WHERE (wm.Sch_Id = td.Sch_Id OR (td.Sch_Id IS NULL AND wm.Task_Id = td.Task_Id))
                      AND wm.Emp_Id = td.Emp_Id 
                      AND CAST(wm.Work_Dt AS DATE) >= CAST(:from_Task_Assign_dt AS DATE)
                )
            )`;
            replacements.from_Task_Assign_dt = startDate;
        } else if (to_Task_Assign_dt) {
            const endDate = new Date(to_Task_Assign_dt);
            endDate.setHours(23, 59, 59, 999);
            whereClause += ' AND td.Task_Assign_dt <= :to_Task_Assign_dt';
            replacements.to_Task_Assign_dt = endDate;
        }

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                COALESCE(ps.Task_Sch_Timer_Based, latest_ps.Task_Sch_Timer_Based) as Schedule_Task_Sch_Timer_Based,
                COALESCE(ps.Sch_No, latest_ps.Sch_No) as Schedule_Sch_No,
                COALESCE(ps.Sch_Date, latest_ps.Sch_Date) as Schedule_Sch_Date,
                COALESCE(ps.Task_Type_Id, latest_ps.Task_Type_Id) as Schedule_Task_Type_Id,
                COALESCE(ps.Sch_Plan_Id, latest_ps.Sch_Plan_Id) as Schedule_Sch_Plan_Id,
                COALESCE(ps.Sch_Start_Date, latest_ps.Sch_Start_Date) as Schedule_Sch_Start_Date,
                COALESCE(ps.Sch_End_Date, latest_ps.Sch_End_Date) as Schedule_Sch_End_Date,
                COALESCE(ps.Task_Sch_Duaration, latest_ps.Task_Sch_Duaration) as Schedule_Task_Sch_Duaration,
                COALESCE(ps.Sch_Status, latest_ps.Sch_Status) as Schedule_Sch_Status,
                ${hasSchCompDateCol ? 'COALESCE(ps.Sch_Comp_Date, latest_ps.Sch_Comp_Date)' : 'NULL'} as Schedule_Sch_Comp_Date,
                ${hasUpdateDateCol ? 'COALESCE(ps.Update_Date, latest_ps.Update_Date)' : 'NULL'} as Schedule_Update_Date,
                ${hasTicketIdCol ? 'COALESCE(ps.Ticket_Id, latest_ps.Ticket_Id)' : 'NULL'} as Schedule_Ticket_Id,
                ${hasTicketIdCol ? 'COALESCE(ps.Ticket_Id, latest_ps.Ticket_Id)' : 'NULL'} as Ticket_Id,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td WITH (NOLOCK)
             LEFT JOIN tbl_Project_Schedule ps WITH (NOLOCK) ON ps.Sch_Id = td.Sch_Id
             OUTER APPLY (
                 SELECT TOP 1 
                     ps2.Task_Sch_Timer_Based, ps2.Sch_No, ps2.Sch_Date, ps2.Task_Type_Id,
                     ps2.Sch_Plan_Id, ps2.Sch_Start_Date, ps2.Sch_End_Date,
                     ps2.Task_Sch_Duaration, ps2.Sch_Status${outerApplyExtraCols ? `,
                     ${outerApplyExtraCols}` : ''}
                 FROM tbl_Project_Schedule ps2 WITH (NOLOCK)
                 WHERE td.Sch_Id IS NULL AND ps2.Task_Id = td.Task_Id
                 ORDER BY ps2.Sch_Id DESC
             ) latest_ps
             LEFT JOIN tbl_Task t WITH (NOLOCK) ON td.Task_Id = t.Task_Id
             WHERE ${whereClause}
             ORDER BY ${sortBy} ${sortOrder}`,
            {
                replacements,
                type: 'SELECT'
            }
        );

        const reqDateParam = to_Task_Assign_dt || from_Task_Assign_dt;
        const targetDateObj = reqDateParam ? new Date(reqDateParam) : null;
        if (targetDateObj) {
            targetDateObj.setHours(0, 0, 0, 0);
        }

        const startDateObj = from_Task_Assign_dt ? new Date(from_Task_Assign_dt) : null;
        if (startDateObj) startDateObj.setHours(0, 0, 0, 0);

        const endDateObj = to_Task_Assign_dt ? new Date(to_Task_Assign_dt) : null;
        if (endDateObj) endDateObj.setHours(23, 59, 59, 999);

        const finalRows: any[] = [];
        const pastRowGroups: { [key: string]: any[] } = {};

        for (const row of (rows || [])) {
            const taskDateObj = row.Task_Assign_dt ? new Date(row.Task_Assign_dt) : null;

            const isInsideRange = taskDateObj &&
                (!startDateObj || taskDateObj >= startDateObj) &&
                (!endDateObj || taskDateObj <= endDateObj);

            const isTicketSchedule = Boolean(
                row.Schedule_Ticket_Id != null ||
                row.Ticket_Id != null ||
                (row.Schedule_Sch_No && (String(row.Schedule_Sch_No).includes('TCK') || String(row.Schedule_Sch_No).startsWith('SCH-')))
            );

            const targetDateStr = targetDateObj ? targetDateObj.toISOString().split('T')[0] : '';
            const compDateStr = row.Schedule_Sch_Comp_Date ? new Date(row.Schedule_Sch_Comp_Date).toISOString().split('T')[0] : '';
            const updateDateStr = row.Schedule_Update_Date ? new Date(row.Schedule_Update_Date).toISOString().split('T')[0] : '';
            const isCompletedOnTargetDate = (row.Schedule_Sch_Status === 3) && (compDateStr === targetDateStr || updateDateStr === targetDateStr);

            // Past tasks should carry forward to targetDateObj (current date) if:
            // 1. Not completed (row.Schedule_Sch_Status !== 3)
            // 2. Completed on targetDateObj (isCompletedOnTargetDate)
            // 3. Ticket schedule completed on targetDateObj / current date (isTicketSchedule && row.Schedule_Sch_Status === 3)
            const shouldCarryForward = Boolean(
                targetDateObj && taskDateObj && taskDateObj < targetDateObj &&
                (row.Schedule_Sch_Status !== 3 || isCompletedOnTargetDate || (isTicketSchedule && row.Schedule_Sch_Status === 3))
            );

            if (isInsideRange) {
                finalRows.push(row);
            } else if (shouldCarryForward) {
                const key = `${row.Sch_Id}_${row.Emp_Id || 0}_${row.Task_Id || 0}`;
                if (!pastRowGroups[key]) {
                    pastRowGroups[key] = [];
                }
                pastRowGroups[key].push(row);
            }
        }

        for (const key of Object.keys(pastRowGroups)) {
            const group = pastRowGroups[key];
            group.sort((a, b) => new Date(b.Task_Assign_dt).getTime() - new Date(a.Task_Assign_dt).getTime());
            const latestPastRow = group[0];
            latestPastRow.Task_Assign_dt = targetDateObj!.toISOString();
            finalRows.push(latestPastRow);
        }

        // Deduplicate per schedule, employee, and assigned date (Sch_Id + Emp_Id + Task_Assign_dt)
        // so every assigned date card is correctly preserved and listed for its assigned date
        const uniqueScheduleMap = new Map<string, any>();
        for (const row of finalRows) {
            const dateStr = row.Task_Assign_dt ? new Date(row.Task_Assign_dt).toISOString().split('T')[0] : '';
            const schKey = row.Sch_Id ? `${row.Sch_Id}_${row.Emp_Id || 0}_${dateStr}` : `td_${row.Id}`;
            if (!uniqueScheduleMap.has(schKey)) {
                uniqueScheduleMap.set(schKey, row);
            }
        }

        const mappedRows = Array.from(uniqueScheduleMap.values()).map(mapRawToTaskDetail);

        taskDetailListCache.set(cacheKey, {
            data: mappedRows,
            expiry: Date.now() + TASK_DETAIL_CACHE_TTL
        });

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailById = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const id = parseIdParam(req.params.id);
        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'Invalid ID parameter'
            });
        }

        const validation = validateWithZod<{ id: number }>(taskDetailIdSchema, { id });

        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Id = :id`,
            {
                replacements: { id },
                type: 'SELECT'
            }
        );

        const taskDetail = rows && rows.length > 0 ? rows[0] : null;

        if (!taskDetail) {
            return notFound(res, 'Task detail not found');
        }

        const mappedTaskDetail = mapRawToTaskDetail(taskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task detail retrieved successfully',
            data: mappedTaskDetail
        });

    } catch (error: any) {
        console.error('Error fetching task detail:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsByProject = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const projectIdParam = getStringParam(req.params.projectId);

        if (!projectIdParam || isNaN(parseInt(projectIdParam))) {
            return res.status(400).json({
                success: false,
                message: 'Valid project ID is required'
            });
        }

        const projectId = parseInt(projectIdParam);

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Project_Id = :projectId
             ORDER BY td.Id DESC`,
            {
                replacements: { projectId },
                type: 'SELECT'
            }
        );

        const mappedRows = (rows || []).map(mapRawToTaskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details by project:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsBySchedule = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const schIdParam = getStringParam(req.params.schId);

        if (!schIdParam || isNaN(parseInt(schIdParam))) {
            return res.status(400).json({
                success: false,
                message: 'Valid schedule ID is required'
            });
        }

        const schId = parseInt(schIdParam);

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Sch_Id = :schId
             ORDER BY td.Id DESC`,
            {
                replacements: { schId },
                type: 'SELECT'
            }
        );

        const mappedRows = (rows || []).map(mapRawToTaskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details by schedule:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsByTask = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const taskIdParam = getStringParam(req.params.taskId);

        if (!taskIdParam || isNaN(parseInt(taskIdParam))) {
            return res.status(400).json({
                success: false,
                message: 'Valid task ID is required'
            });
        }

        const taskId = parseInt(taskIdParam);

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Task_Id = :taskId
             ORDER BY td.Id DESC`,
            {
                replacements: { taskId },
                type: 'SELECT'
            }
        );

        const mappedRows = (rows || []).map(mapRawToTaskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details by task:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsByEmployee = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const empIdParam = getStringParam(req.params.empId);

        if (!empIdParam || isNaN(parseInt(empIdParam))) {
            return res.status(400).json({
                success: false,
                message: 'Valid employee ID is required'
            });
        }

        const empId = parseInt(empIdParam);

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Emp_Id = :empId
             ORDER BY td.Id DESC`,
            {
                replacements: { empId },
                type: 'SELECT'
            }
        );

        const mappedRows = (rows || []).map(mapRawToTaskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details by employee:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsWithFilters = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);

        const validation = validateWithZod<TaskDetailQueryParams>(taskDetailQuerySchema, req.query);

        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        const {
            Project_Ids,
            Task_Ids,
            Emp_Ids,
            has_AN_No,
            has_Assigned_Emp,
            sortBy = 'td.Id',
            sortOrder = 'DESC'
        } = validation.data!;

        let whereClause = '1=1';
        const replacements: any = {};

        if (Project_Ids && Project_Ids.length > 0) {
            whereClause += ' AND td.Project_Id IN (:Project_Ids)';
            replacements.Project_Ids = Project_Ids;
        }

        if (Task_Ids && Task_Ids.length > 0) {
            whereClause += ' AND td.Task_Id IN (:Task_Ids)';
            replacements.Task_Ids = Task_Ids;
        }

        if (Emp_Ids && Emp_Ids.length > 0) {
            whereClause += ' AND td.Emp_Id IN (:Emp_Ids)';
            replacements.Emp_Ids = Emp_Ids;
        }

        if (has_AN_No !== undefined) {
            if (has_AN_No) {
                whereClause += ' AND td.AN_No IS NOT NULL';
            } else {
                whereClause += ' AND td.AN_No IS NULL';
            }
        }

        if (has_Assigned_Emp !== undefined) {
            if (has_Assigned_Emp) {
                whereClause += ' AND td.Assigned_Emp_Id IS NOT NULL';
            } else {
                whereClause += ' AND td.Assigned_Emp_Id IS NULL';
            }
        }

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE ${whereClause}
             ORDER BY ${sortBy} ${sortOrder}`,
            {
                replacements,
                type: 'SELECT'
            }
        );

        const mappedRows = (rows || []).map(mapRawToTaskDetail);

        return res.status(200).json({
            success: true,
            message: 'Task details retrieved successfully',
            data: mappedRows
        });

    } catch (error: any) {
        console.error('Error fetching task details with filters:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const updateTaskDetail = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);
        const TaskDetailModel = getTaskDetailModel(companyDB);

        const id = parseIdParam(req.params.id);
        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'Invalid ID parameter'
            });
        }

        const idValidation = validateWithZod<{ id: number }>(taskDetailIdSchema, { id });

        if (!idValidation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: idValidation.errors
            });
        }

        const bodyValidation = validateWithZod<TaskDetailUpdateInput>(taskDetailUpdateSchema, req.body);

        if (!bodyValidation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: bodyValidation.errors
            });
        }

        const updateData = { ...bodyValidation.data! };
        delete updateData.taskDates;

        const taskDetail = await TaskDetailModel.findByPk(id);

        if (!taskDetail) {
            return notFound(res, 'Task detail not found');
        }

        // If updating Sch_Id, Emp_Id, or Task_Assign_dt, check for duplicates
        if (updateData.Sch_Id || updateData.Emp_Id || updateData.Task_Assign_dt) {
            const newSchId = updateData.Sch_Id !== undefined ? updateData.Sch_Id : taskDetail.Sch_Id;
            const newEmpId = updateData.Emp_Id !== undefined ? updateData.Emp_Id : taskDetail.Emp_Id;
            const newTaskAssignDt = updateData.Task_Assign_dt !== undefined ? updateData.Task_Assign_dt : taskDetail.Task_Assign_dt;

            const duplicateCheck: any[] = await companyDB.query(
                `SELECT Id FROM tbl_Task_Details 
                 WHERE Sch_Id = :schId 
                   AND Emp_Id = :empId 
                   AND Task_Assign_dt >= CAST(:taskAssignDt AS DATETIME)
                   AND Task_Assign_dt < DATEADD(day, 1, CAST(:taskAssignDt AS DATETIME))
                   AND Id != :id`,
                {
                    replacements: {
                        schId: newSchId,
                        empId: newEmpId,
                        taskAssignDt: newTaskAssignDt,
                        id: id
                    },
                    type: 'SELECT'
                }
            );

            if (duplicateCheck && duplicateCheck.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Duplicate record found: Same Sch_Id, Emp_Id, and Task_Assign_dt combination already exists',
                    duplicateId: duplicateCheck[0].Id
                });
            }
        }

        await taskDetail.update(updateData);

        const rows: any[] = await companyDB.query(
            `SELECT 
                td.*,
                ps.Task_Sch_Timer_Based as Schedule_Task_Sch_Timer_Based,
                ps.Sch_No as Schedule_Sch_No,
                ps.Sch_Date as Schedule_Sch_Date,
                ps.Task_Type_Id as Schedule_Task_Type_Id,
                ps.Sch_Plan_Id as Schedule_Sch_Plan_Id,
                ps.Sch_Start_Date as Schedule_Sch_Start_Date,
                ps.Sch_End_Date as Schedule_Sch_End_Date,
                ps.Task_Sch_Duaration as Schedule_Task_Sch_Duaration,
                ps.Sch_Status as Schedule_Sch_Status,
                t.Task_Name,
                t.Task_Desc,
                t.Task_Type_Id
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id
             LEFT JOIN tbl_Task t ON td.Task_Id = t.Task_Id
             WHERE td.Id = :id`,
            {
                replacements: { id },
                type: 'SELECT'
            }
        );

        const updatedTaskDetail = rows && rows.length > 0 ? rows[0] : null;

        if (!updatedTaskDetail) {
            return notFound(res, 'Task detail not found after update');
        }

        const mappedTaskDetail = mapRawToTaskDetail(updatedTaskDetail);

        invalidateTaskDetailCache();

        return updated(res, {
            success: true,
            message: 'Task detail updated successfully',
            data: mappedTaskDetail
        });

    } catch (error: any) {
        console.error('Error updating task detail:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const deleteTaskDetail = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);
        const TaskDetailModel = getTaskDetailModel(companyDB);

        const id = parseIdParam(req.params.id);
        if (!id) {
            return res.status(400).json({
                success: false,
                message: 'Invalid ID parameter'
            });
        }

        const validation = validateWithZod<{ id: number }>(taskDetailIdSchema, { id });

        if (!validation.success) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: validation.errors
            });
        }

        const taskDetail = await TaskDetailModel.findByPk(id);

        if (!taskDetail) {
            return notFound(res, 'Task detail not found');
        }

        await taskDetail.destroy();

        invalidateTaskDetailCache();

        return res.status(200).json({
            success: true,
            message: 'Task detail deleted successfully'
        });

    } catch (error: any) {
        console.error('Error deleting task detail:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const getTaskDetailsStatistics = async (req: Request, res: Response) => {
    try {
        const companyDB = getCompanyDB(req);
        const TaskDetailModel = getTaskDetailModel(companyDB);

        const totalRecords = await TaskDetailModel.count();
        const recordsWithAN = await TaskDetailModel.count({ where: { AN_No: { [Op.ne]: null } } });
        const recordsWithAssignedEmp = await TaskDetailModel.count({ where: { Assigned_Emp_Id: { [Op.ne]: null } } });

        const statusCounts = await TaskDetailModel.findAll({
            attributes: ['Invovled_Stat', [companyDB.fn('COUNT', companyDB.col('Invovled_Stat')), 'count']],
            where: { Invovled_Stat: { [Op.ne]: null } },
            group: ['Invovled_Stat']
        });

        const timerBasedStatsResult: any = await companyDB.query(
            `SELECT 
                COUNT(DISTINCT td.Task_Id) as tasksWithTimerBased,
                SUM(CASE WHEN ps.Task_Sch_Timer_Based = 1 THEN 1 ELSE 0 END) as timerBasedCount
             FROM tbl_Task_Details td
             LEFT JOIN tbl_Project_Schedule ps ON td.Task_Id = ps.Task_Id`,
            { type: 'SELECT' }
        );

        const timerBasedStats = (timerBasedStatsResult && timerBasedStatsResult.length > 0)
            ? timerBasedStatsResult[0]
            : { tasksWithTimerBased: 0, timerBasedCount: 0 };

        return res.status(200).json({
            success: true,
            message: 'Statistics retrieved successfully',
            data: {
                totalRecords,
                recordsWithAN,
                recordsWithAssignedEmp,
                recordsWithoutAN: totalRecords - recordsWithAN,
                recordsWithoutAssignedEmp: totalRecords - recordsWithAssignedEmp,
                statusDistribution: statusCounts,
                scheduleStats: timerBasedStats
            }
        });

    } catch (error: any) {
        console.error('Error fetching statistics:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

export const createTaskDetailsRaw = async (req: Request, res: Response) => {
    const companyDB = getCompanyDB(req);
    const transaction = await companyDB.transaction();

    try {
        const validation = validateWithZod<TaskDetailCreateInput>(
            taskDetailCreateSchema,
            req.body
        );

        if (!validation.success) {
            await transaction.rollback();
            return res.status(400).json({
                success: false,
                message: "Validation failed",
                errors: validation.errors
            });
        }

        const {
            Project_Id,
            Sch_Id,
            Task_Id,
            Emp_Ids,
            Task_Levl_Id,
            Assigned_Emp_Id,
            Ord_By,
            Invovled_Stat,
            taskDates,
            employeeDates
        } = validation.data!;

        // Fetch data from tbl_Project_Sch_Task_DT based on Sch_Id
        let scheduleTaskData: any[] = await companyDB.query(
            `SELECT 
                Task_Work_Date,
                Task_Start_Time,
                Task_End_Time
             FROM tbl_Project_Sch_Task_DT 
             WHERE Sch_Id = :schId
             ORDER BY Task_Work_Date ASC`,
            {
                replacements: { schId: Sch_Id },
                type: 'SELECT',
                transaction
            }
        );

        if (scheduleTaskData && scheduleTaskData.length > 0 && taskDates && taskDates.length > 0) {
            scheduleTaskData = scheduleTaskData.filter(task => {
                let taskDateStr = "";
                if (typeof task.Task_Work_Date === 'string') {
                    taskDateStr = task.Task_Work_Date.split('T')[0];
                } else {
                    const d = new Date(task.Task_Work_Date);
                    const offset = d.getTimezoneOffset() * 60000;
                    taskDateStr = new Date(d.getTime() - offset).toISOString().split('T')[0];
                }
                const fallbackStr = new Date(task.Task_Work_Date).toISOString().split('T')[0];
                return taskDates.includes(taskDateStr) || taskDates.includes(fallbackStr);
            });
        }

        // Always fetch the master data to use as a fallback for missing times
        const schMasterData: any[] = await companyDB.query(
            `SELECT Sch_Start_Date, Sch_Est_Start_Time, Sch_Est_End_Time FROM tbl_Project_Schedule WHERE Sch_Id = :schId`,
            { replacements: { schId: Sch_Id }, type: 'SELECT', transaction }
        );
        const masterEstStart = (schMasterData && schMasterData.length > 0) ? schMasterData[0].Sch_Est_Start_Time : null;
        const masterEstEnd = (schMasterData && schMasterData.length > 0) ? schMasterData[0].Sch_Est_End_Time : null;

        // If after filtering (or if it was initially empty) we have nothing, but taskDates were provided, generate them
        if ((!scheduleTaskData || scheduleTaskData.length === 0) && taskDates && taskDates.length > 0) {
            scheduleTaskData = taskDates.map(dateStr => ({
                Task_Work_Date: dateStr,
                Task_Start_Time: masterEstStart,
                Task_End_Time: masterEstEnd
            }));
        }

        // Fallback to schedule start date if no dates found and no dates provided
        if (!scheduleTaskData || scheduleTaskData.length === 0) {
            if (schMasterData && schMasterData.length > 0 && schMasterData[0].Sch_Start_Date) {
                scheduleTaskData = [{
                    Task_Work_Date: schMasterData[0].Sch_Start_Date,
                    Task_Start_Time: masterEstStart,
                    Task_End_Time: masterEstEnd
                }];
            }
        }

        // Ensure any existing rows that have null times get the defaults
        if (scheduleTaskData && scheduleTaskData.length > 0) {
            scheduleTaskData = scheduleTaskData.map(t => ({
                ...t,
                Task_Start_Time: t.Task_Start_Time || masterEstStart,
                Task_End_Time: t.Task_End_Time || masterEstEnd
            }));
        }

        if (!scheduleTaskData || scheduleTaskData.length === 0) {
            if (Emp_Ids && Emp_Ids.length > 0) {
                await transaction.rollback();
                return res.status(404).json({
                    success: false,
                    message: `No schedule task data found for Sch_Id: ${Sch_Id}`
                });
            } else {
                // If there's no scheduleTaskData AND no employees, it's just a clear operation.
                scheduleTaskData = [];
            }
        }

        // --- DELETE removed dates and unselected employees ---
        const existingAssignments: any[] = await companyDB.query(
            `SELECT Id, Emp_Id, Task_Assign_dt FROM tbl_Task_Details WHERE Sch_Id = :schId AND Task_Id = :taskId`,
            {
                replacements: { schId: Sch_Id, taskId: Task_Id },
                transaction,
                type: 'SELECT'
            }
        );

        const deleteIds: number[] = [];
        for (const row of existingAssignments) {
            // If employee is no longer selected at all, delete their assignment
            if (!Emp_Ids || !Emp_Ids.includes(row.Emp_Id)) {
                deleteIds.push(row.Id);
                continue;
            }

            // Otherwise, check if the date is still valid
            let rowDateStr = "";
            if (typeof row.Task_Assign_dt === 'string') {
                rowDateStr = row.Task_Assign_dt.split('T')[0].split(' ')[0]; // Handles both '2026-07-22' and '2026-07-22 00:00:00'
            } else {
                const d = new Date(row.Task_Assign_dt);
                const offset = d.getTimezoneOffset() * 60000;
                rowDateStr = new Date(d.getTime() - offset).toISOString().split('T')[0];
            }

            // Figure out valid dates for this specific employee
            let empValidDateStrings: string[] = [];
            if (employeeDates && employeeDates[row.Emp_Id.toString()]) {
                empValidDateStrings = employeeDates[row.Emp_Id.toString()] as string[];
            } else if (scheduleTaskData && scheduleTaskData.length > 0) {
                empValidDateStrings = scheduleTaskData.map(t => {
                    let taskDateStr = "";
                    if (typeof t.Task_Work_Date === 'string') {
                        taskDateStr = t.Task_Work_Date.split('T')[0];
                    } else {
                        const d = new Date(t.Task_Work_Date);
                        const offset = d.getTimezoneOffset() * 60000;
                        taskDateStr = new Date(d.getTime() - offset).toISOString().split('T')[0];
                    }
                    return taskDateStr;
                });
            }

            if (!empValidDateStrings.includes(rowDateStr)) {
                deleteIds.push(row.Id);
            }
        }

        if (deleteIds.length > 0) {
            const placeholders = deleteIds.join(',');
            await companyDB.query(
                `DELETE FROM tbl_Task_Details WHERE Id IN (${placeholders})`,
                {
                    transaction
                }
            );
        }
        // --- END DELETE ---

        // Get the current max AN_No to generate next values
        const maxAnNoResult: any = await companyDB.query(
            `SELECT ISNULL(MAX(AN_No), 0) AS maxANNo FROM tbl_Task_Details`,
            { transaction, type: 'SELECT' }
        );

        let nextANNo = (maxAnNoResult[0]?.maxANNo || 0) + 1;
        const insertedAN_NoValues: number[] = [];
        let totalRecordsCreated = 0;
        const duplicateRecords: any[] = [];
        const successfulRecords: any[] = [];

        // For each employee and each schedule task record, create a task detail
        for (let i = 0; i < Emp_Ids.length; i++) {
            const currentEmpId = Emp_Ids[i];
            let empScheduleTaskData = scheduleTaskData;

            if (employeeDates && employeeDates[currentEmpId.toString()]) {
                const customDates = employeeDates[currentEmpId.toString()] as string[];
                empScheduleTaskData = scheduleTaskData.filter(task => {
                    let taskDateStr = "";
                    if (typeof task.Task_Work_Date === 'string') {
                        taskDateStr = task.Task_Work_Date.split('T')[0];
                    } else {
                        const d = new Date(task.Task_Work_Date);
                        const offset = d.getTimezoneOffset() * 60000;
                        taskDateStr = new Date(d.getTime() - offset).toISOString().split('T')[0];
                    }
                    const fallbackStr = new Date(task.Task_Work_Date).toISOString().split('T')[0];
                    return customDates.includes(taskDateStr) || customDates.includes(fallbackStr);
                });
            }

            for (let j = 0; j < empScheduleTaskData.length; j++) {
                const taskRecord = empScheduleTaskData[j] as ScheduleTaskData;
                const twd: any = taskRecord.Task_Work_Date;
                const recordDateStr = typeof twd === 'string'
                    ? twd.substring(0, 10)
                    : new Date(twd).toISOString().substring(0, 10);

                // Check if duplicate exists for Sch_Id, Emp_Id, Task_Id and Task_Assign_dt (date only)
                const checkDuplicate: any[] = await companyDB.query(
                    `SELECT Id FROM tbl_Task_Details 
                     WHERE Sch_Id = :schId 
                       AND Emp_Id = :empId 
                       AND Task_Id = :taskId
                       AND Task_Assign_dt >= CAST(:taskAssignDt AS DATETIME)
                   AND Task_Assign_dt < DATEADD(day, 1, CAST(:taskAssignDt AS DATETIME))`,
                    {
                        replacements: {
                            schId: Sch_Id,
                            empId: currentEmpId,
                            taskId: Task_Id,
                            taskAssignDt: recordDateStr
                        },
                        transaction,
                        type: 'SELECT'
                    }
                );

                if (checkDuplicate && checkDuplicate.length > 0) {
                    // Record duplicate found - skip insertion
                    duplicateRecords.push({
                        employeeId: Emp_Ids[i],
                        scheduleDate: taskRecord.Task_Work_Date,
                        existingId: checkDuplicate[0].Id
                    });
                    continue;
                }

                // Insert new record if no duplicate found
                await companyDB.query(
                    `INSERT INTO tbl_Task_Details
                    (AN_No, Project_Id, Sch_Id, Task_Levl_Id, Task_Id, Assigned_Emp_Id, Emp_Id, 
                     Task_Assign_dt, Sch_Time, EN_Time, Ord_By, Invovled_Stat)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    {
                        replacements: [
                            nextANNo,
                            Project_Id,
                            Sch_Id,
                            Task_Levl_Id || null,
                            Task_Id,
                            Assigned_Emp_Id || null,
                            Emp_Ids[i],
                            recordDateStr,
                            taskRecord.Task_Start_Time,
                            taskRecord.Task_End_Time,
                            Ord_By || null,
                            Invovled_Stat || null
                        ],
                        transaction,
                        type: 'INSERT'
                    }
                );

                insertedAN_NoValues.push(nextANNo);
                successfulRecords.push({
                    employeeId: Emp_Ids[i],
                    scheduleDate: taskRecord.Task_Work_Date,
                    anNo: nextANNo
                });
                totalRecordsCreated++;
                nextANNo++;
            }
        }

        await transaction.commit();

        let message = `Task details created successfully`;
        if (successfulRecords.length > 0) {
            message = `${totalRecordsCreated} record(s) created for ${Emp_Ids.length} employee(s) across ${scheduleTaskData.length} schedule task record(s)`;
        }
        if (duplicateRecords.length > 0) {
            message += `. ${duplicateRecords.length} duplicate record(s) skipped (duplicate: Sch_Id + Emp_Id + Task_Assign_dt)`;
        }

        invalidateTaskDetailCache();

        return res.status(201).json({
            success: true,
            message: message,
            data: {
                totalRecords: totalRecordsCreated,
                employeeCount: Emp_Ids.length,
                scheduleTaskCount: scheduleTaskData.length,
                employeeIds: Emp_Ids,
                scheduleTaskDates: scheduleTaskData.map((record: ScheduleTaskData) => ({
                    taskWorkDate: record.Task_Work_Date,
                    taskStartTime: record.Task_Start_Time,
                    taskEndTime: record.Task_End_Time
                })),
                anNoValuesUsed: insertedAN_NoValues,
                duplicateSkipped: duplicateRecords.length > 0 ? {
                    count: duplicateRecords.length,
                    details: duplicateRecords
                } : undefined,
                successfulRecords: successfulRecords
            }
        });

    } catch (error: any) {
        try {
            await transaction.rollback();
        } catch (rollbackError) {
            console.error("Error rolling back transaction:", rollbackError);
        }
        console.error("Error creating task details:", error);
        return res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
};

export const updateTaskDetailsBulk = async (req: Request, res: Response) => {
    const companyDB = getCompanyDB(req);
    const transaction = await companyDB.transaction();

    try {
        const { projectId, schId, taskId, empId, Ord_By, Invovled_Stat, taskDates } = req.body;

        if (!projectId || !schId || !taskId || !empId) {
            await transaction.rollback();
            return res.status(400).json({
                success: false,
                message: "Missing required fields: projectId, schId, taskId, empId"
            });
        }

        // Fetch data from tbl_Project_Sch_Task_DT based on schId
        let scheduleTaskData: any[] = await companyDB.query(
            `SELECT 
                Task_Work_Date,
                Task_Start_Time,
                Task_End_Time
             FROM tbl_Project_Sch_Task_DT 
             WHERE Sch_Id = :schId
             ORDER BY Task_Work_Date ASC`,
            {
                replacements: { schId },
                type: 'SELECT',
                transaction
            }
        );

        if (scheduleTaskData && scheduleTaskData.length > 0 && taskDates && taskDates.length > 0) {
            scheduleTaskData = scheduleTaskData.filter(task => {
                let taskDateStr = "";
                if (typeof task.Task_Work_Date === 'string') {
                    taskDateStr = task.Task_Work_Date.split('T')[0];
                } else {
                    const d = new Date(task.Task_Work_Date);
                    const offset = d.getTimezoneOffset() * 60000;
                    taskDateStr = new Date(d.getTime() - offset).toISOString().split('T')[0];
                }
                const fallbackStr = new Date(task.Task_Work_Date).toISOString().split('T')[0];
                return taskDates.includes(taskDateStr) || taskDates.includes(fallbackStr);
            });
        }

        // Always fetch the master data to use as a fallback for missing times
        const schMasterData: any[] = await companyDB.query(
            `SELECT Sch_Start_Date, Sch_Est_Start_Time, Sch_Est_End_Time FROM tbl_Project_Schedule WHERE Sch_Id = :schId`,
            { replacements: { schId }, type: 'SELECT', transaction }
        );
        const masterEstStart = (schMasterData && schMasterData.length > 0) ? schMasterData[0].Sch_Est_Start_Time : null;
        const masterEstEnd = (schMasterData && schMasterData.length > 0) ? schMasterData[0].Sch_Est_End_Time : null;

        if ((!scheduleTaskData || scheduleTaskData.length === 0) && taskDates && taskDates.length > 0) {
            scheduleTaskData = taskDates.map((dateStr: string) => ({
                Task_Work_Date: new Date(dateStr),
                Task_Start_Time: masterEstStart,
                Task_End_Time: masterEstEnd
            }));
        }

        // Fallback to schedule start date if no dates found and no dates provided
        if (!scheduleTaskData || scheduleTaskData.length === 0) {
            if (schMasterData && schMasterData.length > 0 && schMasterData[0].Sch_Start_Date) {
                scheduleTaskData = [{
                    Task_Work_Date: schMasterData[0].Sch_Start_Date,
                    Task_Start_Time: masterEstStart,
                    Task_End_Time: masterEstEnd
                }];
            }
        }

        // Ensure any existing rows that have null times get the defaults
        if (scheduleTaskData && scheduleTaskData.length > 0) {
            scheduleTaskData = scheduleTaskData.map(t => ({
                ...t,
                Task_Start_Time: t.Task_Start_Time || masterEstStart,
                Task_End_Time: t.Task_End_Time || masterEstEnd
            }));
        }

        if (!scheduleTaskData || scheduleTaskData.length === 0) {
            await transaction.rollback();
            return res.status(404).json({
                success: false,
                message: `No schedule task data found for Sch_Id: ${schId}`
            });
        }

        // Get existing records for this combination
        const existingRecords: any[] = await companyDB.query(
            `SELECT Id, Task_Assign_dt FROM tbl_Task_Details 
             WHERE Sch_Id = :schId AND Emp_Id = :empId AND Task_Id = :taskId AND Project_Id = :projectId`,
            {
                replacements: { schId, empId, taskId, projectId },
                transaction,
                type: 'SELECT'
            }
        );

        // Create a map of existing Task_Assign_dt dates
        const existingDatesMap = new Map();
        existingRecords.forEach(record => {
            const dateKey = new Date(record.Task_Assign_dt).toISOString().split('T')[0];
            existingDatesMap.set(dateKey, record.Id);
        });

        // Get the current max AN_No to generate next values
        const maxAnNoResult: any = await companyDB.query(
            `SELECT ISNULL(MAX(AN_No), 0) AS maxANNo FROM tbl_Task_Details`,
            { transaction, type: 'SELECT' }
        );

        let nextANNo = (maxAnNoResult[0]?.maxANNo || 0) + 1;
        const insertedAN_NoValues: number[] = [];
        const updatedRecords: any[] = [];
        const duplicateRecords: any[] = [];
        const scheduleDates = scheduleTaskData.map((record: ScheduleTaskData) =>
            new Date(record.Task_Work_Date).toISOString().split('T')[0]
        );

        // Records to delete (dates not in new schedule)
        const recordsToDelete = existingRecords.filter(record => {
            const recordDate = new Date(record.Task_Assign_dt).toISOString().split('T')[0];
            return !scheduleDates.includes(recordDate);
        });

        if (recordsToDelete.length > 0) {
            const deleteIds = recordsToDelete.map(r => r.Id);
            const placeholders = deleteIds.map(() => '?').join(',');
            await companyDB.query(
                `DELETE FROM tbl_Task_Details WHERE Id IN (${placeholders})`,
                {
                    replacements: deleteIds,
                    transaction,
                    type: 'DELETE'
                }
            );
        }

        // Insert or update records
        for (let j = 0; j < scheduleTaskData.length; j++) {
            const taskRecord = scheduleTaskData[j] as ScheduleTaskData;
            const recordDate = new Date(taskRecord.Task_Work_Date).toISOString().split('T')[0];

            // Check if record already exists
            if (existingDatesMap.has(recordDate)) {
                // Update existing record
                await companyDB.query(
                    `UPDATE tbl_Task_Details 
                     SET Sch_Time = ?, EN_Time = ?, Ord_By = ?, Invovled_Stat = ?
                     WHERE Id = ?`,
                    {
                        replacements: [
                            taskRecord.Task_Start_Time,
                            taskRecord.Task_End_Time,
                            Ord_By || null,
                            Invovled_Stat || null,
                            existingDatesMap.get(recordDate)
                        ],
                        transaction,
                        type: 'UPDATE'
                    }
                );
                updatedRecords.push({
                    scheduleDate: taskRecord.Task_Work_Date,
                    action: 'updated',
                    id: existingDatesMap.get(recordDate)
                });
            } else {
                // Check for duplicate with same Sch_Id, Emp_Id, Task_Assign_dt
                const checkDuplicate: any[] = await companyDB.query(
                    `SELECT Id FROM tbl_Task_Details 
                     WHERE Sch_Id = :schId 
                       AND Emp_Id = :empId 
                       AND Task_Assign_dt >= CAST(:taskAssignDt AS DATETIME)
                   AND Task_Assign_dt < DATEADD(day, 1, CAST(:taskAssignDt AS DATETIME))`,
                    {
                        replacements: {
                            schId,
                            empId,
                            taskAssignDt: recordDate
                        },
                        transaction,
                        type: 'SELECT'
                    }
                );

                if (checkDuplicate && checkDuplicate.length > 0) {
                    duplicateRecords.push({
                        scheduleDate: taskRecord.Task_Work_Date,
                        existingId: checkDuplicate[0].Id
                    });
                    continue;
                }

                // Insert new record
                await companyDB.query(
                    `INSERT INTO tbl_Task_Details
                    (AN_No, Project_Id, Sch_Id, Task_Id, Emp_Id, Task_Assign_dt, Sch_Time, EN_Time, Ord_By, Invovled_Stat)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    {
                        replacements: [
                            nextANNo,
                            projectId,
                            schId,
                            taskId,
                            empId,
                            recordDate,
                            taskRecord.Task_Start_Time,
                            taskRecord.Task_End_Time,
                            Ord_By || null,
                            Invovled_Stat || null
                        ],
                        transaction,
                        type: 'INSERT'
                    }
                );

                insertedAN_NoValues.push(nextANNo);
                updatedRecords.push({
                    scheduleDate: taskRecord.Task_Work_Date,
                    action: 'inserted',
                    anNo: nextANNo
                });
                nextANNo++;
            }
        }

        await transaction.commit();

        let message = `Task details updated successfully for employee ${empId}`;
        if (duplicateRecords.length > 0) {
            message += `. ${duplicateRecords.length} duplicate record(s) skipped`;
        }

        invalidateTaskDetailCache();

        return res.status(200).json({
            success: true,
            message: message,
            data: {
                totalRecords: updatedRecords.length,
                employeeId: empId,
                scheduleTaskCount: scheduleTaskData.length,
                scheduleTaskDates: scheduleTaskData.map((record: ScheduleTaskData) => ({
                    taskWorkDate: record.Task_Work_Date,
                    taskStartTime: record.Task_Start_Time,
                    taskEndTime: record.Task_End_Time
                })),
                anNoValuesUsed: insertedAN_NoValues,
                recordsDeleted: recordsToDelete.length,
                updatedRecords: updatedRecords,
                duplicateSkipped: duplicateRecords.length > 0 ? {
                    count: duplicateRecords.length,
                    details: duplicateRecords
                } : undefined
            }
        });

    } catch (error: any) {
        await transaction.rollback();
        console.error("Error updating task details bulk:", error);
        return res.status(500).json({
            success: false,
            message: error.message || "Internal server error"
        });
    }
};