import { Request, Response } from 'express';
import { QueryTypes } from 'sequelize';
import { dataFound, noData, invalidInput, servError } from '../../responseObject';
import {
    AttendanceResult,
    AttendanceSummary,
    DefaultLeaveResult
} from '../../models/Attendance/Fingerprint/fingerPrintAttendance.model';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const formatDateToString = (date: Date): string => {
    const year  = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day   = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const isValidDate = (dateStr: string): boolean =>
    !isNaN(new Date(dateStr).getTime());

const getEmployeeForUser = async (
    db: import('sequelize').Sequelize,
    req: Request
): Promise<{ Emp_Id: number; User_Mgt_Id: number; fingerPrintEmpId: string } | null> => {
    const user = (req as any).user;
    if (!user) return null;

    const localUserId = (req as any).localUserId ?? user.Local_User_ID ?? null;
    const globalUserId = (req as any).userId ?? user.Global_User_ID ?? null;
    const userName = user.UserName ?? null;

    const rows = await db.query<{ Emp_Id: number; User_Mgt_Id: number; fingerPrintEmpId: string }>(
        `SELECT TOP 1 Emp_Id, User_Mgt_Id, fingerPrintEmpId 
         FROM tbl_Employee_Master 
         WHERE (:localUserId IS NOT NULL AND User_Mgt_Id = :localUserId)
            OR (:globalUserId IS NOT NULL AND User_Mgt_Id = :globalUserId)
            OR (:userName IS NOT NULL AND Mobile_No = :userName)`,
        {
            replacements: { localUserId, globalUserId, userName },
            type: QueryTypes.SELECT,
        }
    );

    return rows && rows.length > 0 ? rows[0] : null;
};

// ─── Public controllers ───────────────────────────────────────────────────────

export const getFingerprintAttendance = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { FromDate, ToDate, FingerPrintId, EmpId } = req.query;
        const db = (req as any).companyDB || req.companyDB;

        if (!db) return servError(new Error('Company database connection not found'), res);

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        if (!isValidDate(FromDate as string) || !isValidDate(ToDate as string))
            return invalidInput(res, 'Invalid date format. Use YYYY-MM-DD');

        const toDateObj        = new Date(ToDate as string);
        const adjustedToDate   = new Date(toDateObj);
        adjustedToDate.setDate(adjustedToDate.getDate() + 1);
        const adjustedToDateStr = adjustedToDate.toISOString();

        const user = (req as any).user;
        const userTypeId = user?.UserTypeId ?? (req as any).userTypeId;
        const isAdmin = userTypeId !== undefined && userTypeId !== null && (Number(userTypeId) === 0 || Number(userTypeId) === 1);

        let result: AttendanceResult[];

        if (!isAdmin) {
            // Non-admin user: list ONLY this individual logged-in employee's data
            const empRecord = await getEmployeeForUser(db, req);
            if (!empRecord) {
                return noData(res);
            }
            if (empRecord.fingerPrintEmpId && empRecord.fingerPrintEmpId !== '0') {
                result = await getMultipleEmployeesAttendance(
                    db, FromDate as string, adjustedToDateStr, empRecord.fingerPrintEmpId
                );
            } else if (empRecord.User_Mgt_Id) {
                result = await getMultipleEmployeesAttendance(
                    db, FromDate as string, adjustedToDateStr, undefined, empRecord.User_Mgt_Id
                );
            } else {
                result = [];
            }
        } else {
            // Admin user: all data or query filters
            if (EmpId && EmpId !== '0' && EmpId !== 'ALL') {
                result = await getSingleEmployeeAttendance(
                    db, FromDate as string, adjustedToDateStr, EmpId as string
                );
            } else {
                result = await getMultipleEmployeesAttendance(
                    db, FromDate as string, adjustedToDateStr, FingerPrintId as string | undefined
                );
            }
        }

        return result.length > 0 ? dataFound(res, result) : noData(res);

    } catch (error) {
        console.error('Error in getFingerprintAttendance:', error);
        return servError(error, res);
    }
};

export const getTodayAttendance = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = (req as any).companyDB || req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const today    = formatDateToString(new Date());
        const tomorrow = formatDateToString(
            new Date(new Date().setDate(new Date().getDate() + 1))
        );

        const user = (req as any).user;
        const userTypeId = user?.UserTypeId ?? (req as any).userTypeId;
        const isAdmin = userTypeId !== undefined && userTypeId !== null && (Number(userTypeId) === 0 || Number(userTypeId) === 1);

        let records: AttendanceResult[];

        if (!isAdmin) {
            // Non-admin user: list ONLY this individual logged-in employee's data
            const empRecord = await getEmployeeForUser(db, req);
            if (!empRecord) {
                return dataFound(res, []);
            }
            if (empRecord.fingerPrintEmpId && empRecord.fingerPrintEmpId !== '0') {
                records = await getMultipleEmployeesAttendance(
                    db, today, tomorrow, empRecord.fingerPrintEmpId
                );
            } else if (empRecord.User_Mgt_Id) {
                records = await getMultipleEmployeesAttendance(
                    db, today, tomorrow, undefined, empRecord.User_Mgt_Id
                );
            } else {
                records = [];
            }
        } else {
            // Admin user: all employees
            records = await getMultipleEmployeesAttendance(db, today, tomorrow);
        }

        return dataFound(res, records);

    } catch (error) {
        console.error('Error in getTodayAttendance:', error);
        return servError(error, res);
    }
};

export const getEmployeeAttendanceSummary = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { EmpId, month, year } = req.query;

        if (!EmpId) return invalidInput(res, 'EmpId is required');

        const yearNum  = year  ? Number(year)      : new Date().getFullYear();
        const monthNum = month ? Number(month) - 1 : new Date().getMonth();

        const startDate = new Date(yearNum, monthNum, 1);
        const endDate   = new Date(yearNum, monthNum + 1, 0);

        const fromDateStr = formatDateToString(startDate);
        const toDateStr   = new Date(
            endDate.setDate(endDate.getDate() + 1)
        ).toISOString();

        const records = await getSingleEmployeeAttendance(
            db, fromDateStr, toDateStr, EmpId as string
        );

        const summary: AttendanceSummary = {
            employeeId:           EmpId as string,
            month:                monthNum + 1,
            year:                 yearNum,
            totalDays:            records.length,
            presentDays:          records.filter(r => r.AttendanceStatus === 'P').length,
            absentDays:           records.filter(r => r.AttendanceStatus === 'A').length,
            leaveDays:            records.filter(r => r.AttendanceStatus === 'L').length,
            holidayDays:          records.filter(r => r.AttendanceStatus === 'H').length,
            defaultLeaveDays:     records.filter(r => r.AttendanceStatus === 'DL').length,
            attendancePercentage: records.length > 0
                ? Number(
                    (
                        (records.filter(r => r.AttendanceStatus === 'P').length / records.length) * 100
                    ).toFixed(2)
                  )
                : 0,
        };

        return dataFound(res, [summary]);

    } catch (error) {
        console.error('Error in getEmployeeAttendanceSummary:', error);
        return servError(error, res);
    }
};

export const getEmployeeAttendance = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { empId }            = req.params;
        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        req.query.EmpId = empId;
        return getFingerprintAttendance(req, res);
    } catch (error) {
        console.error('Error in getEmployeeAttendance:', error);
        return servError(error, res);
    }
};

export const getDeviceAttendance = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { deviceId }         = req.params;
        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        req.query.FingerPrintId = deviceId;
        return getFingerprintAttendance(req, res);
    } catch (error) {
        console.error('Error in getDeviceAttendance:', error);
        return servError(error, res);
    }
};

export const getAttendanceByDateRange = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { startDate, endDate } = req.query;

        if (!startDate || !endDate)
            return invalidInput(res, 'startDate and endDate are required');

        req.query.FromDate = startDate as string;
        req.query.ToDate   = endDate   as string;
        return getFingerprintAttendance(req, res);
    } catch (error) {
        console.error('Error in getAttendanceByDateRange:', error);
        return servError(error, res);
    }
};

export const getMonthlyAttendance = async (req: Request, res: Response): Promise<Response> => {
    try {
        const { year, month } = req.params;

        const startDate = new Date(Number(year), Number(month) - 1, 1);
        const endDate   = new Date(Number(year), Number(month),     0);

        req.query.FromDate = formatDateToString(startDate);
        req.query.ToDate   = formatDateToString(endDate);
        return getFingerprintAttendance(req, res);
    } catch (error) {
        console.error('Error in getMonthlyAttendance:', error);
        return servError(error, res);
    }
};

export const getAbsentEmployees = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        const adjustedTo = new Date(
            new Date(ToDate as string).setDate(new Date(ToDate as string).getDate() + 1)
        ).toISOString();

        const records = await getMultipleEmployeesAttendance(
            db, FromDate as string, adjustedTo
        );

        return dataFound(res, records.filter(r => r.AttendanceStatus === 'A'));

    } catch (error) {
        console.error('Error in getAbsentEmployees:', error);
        return servError(error, res);
    }
};

export const getPresentEmployees = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        const adjustedTo = new Date(
            new Date(ToDate as string).setDate(new Date(ToDate as string).getDate() + 1)
        ).toISOString();

        const records = await getMultipleEmployeesAttendance(
            db, FromDate as string, adjustedTo
        );

        return dataFound(res, records.filter(r => r.AttendanceStatus === 'P'));

    } catch (error) {
        console.error('Error in getPresentEmployees:', error);
        return servError(error, res);
    }
};

export const getAttendanceStats = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        const adjustedTo = new Date(
            new Date(ToDate as string).setDate(new Date(ToDate as string).getDate() + 1)
        ).toISOString();

        const records = await getMultipleEmployeesAttendance(
            db, FromDate as string, adjustedTo
        );

        const uniqueEmployees = [...new Set(records.map(r => r.fingerPrintEmpId))].length;
        const presentCount    = records.filter(r => r.AttendanceStatus === 'P').length;
        const absentCount     = records.filter(r => r.AttendanceStatus === 'A').length;
        const leaveCount      = records.filter(r => r.AttendanceStatus === 'L').length;

        return dataFound(res, [{
            totalEmployees: uniqueEmployees,
            totalPresent:   presentCount,
            totalAbsent:    absentCount,
            totalLeave:     leaveCount,
            attendanceRate: records.length > 0
                ? Number(((presentCount / records.length) * 100).toFixed(2))
                : 0,
        }]);

    } catch (error) {
        console.error('Error in getAttendanceStats:', error);
        return servError(error, res);
    }
};

// ─── Default Leave controllers ────────────────────────────────────────────────

export const getAllDefaultLeaves = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const records = await db.query<DefaultLeaveResult>(
            `SELECT SNo, Date, Description, Created_By, Created_At, Modified_By, Modified_At
             FROM tbl_Default_Leave
             ORDER BY Date DESC, SNo DESC`,
            { type: QueryTypes.SELECT }
        );

        return records.length > 0 ? dataFound(res, records) : noData(res);

    } catch (error) {
        console.error('Error in getAllDefaultLeaves:', error);
        return servError(error, res);
    }
};

export const getDefaultLeavesByDateRange = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { FromDate, ToDate } = req.query;

        if (!FromDate || !ToDate)
            return invalidInput(res, 'FromDate and ToDate are required');

        if (!isValidDate(FromDate as string) || !isValidDate(ToDate as string))
            return invalidInput(res, 'Invalid date format. Use YYYY-MM-DD');

        const records = await db.query<DefaultLeaveResult>(
            `SELECT SNo, Date, Description, Created_By, Created_At, Modified_By, Modified_At
             FROM tbl_Default_Leave
             WHERE Date >= :FromDate AND Date <= :ToDate
             ORDER BY Date DESC, SNo DESC`,
            {
                replacements: { FromDate, ToDate },
                type:         QueryTypes.SELECT,
            }
        );

        return records.length > 0 ? dataFound(res, records) : noData(res);

    } catch (error) {
        console.error('Error in getDefaultLeavesByDateRange:', error);
        return servError(error, res);
    }
};

export const getDefaultLeaveById = async (req: Request, res: Response): Promise<Response> => {
    try {
        const db = req.companyDB;
        if (!db) return servError(new Error('Company database connection not found'), res);

        const { id } = req.params;
        if (!id) return invalidInput(res, 'ID is required');

        const records = await db.query<DefaultLeaveResult>(
            `SELECT SNo, Date, Description, Created_By, Created_At, Modified_By, Modified_At
             FROM tbl_Default_Leave
             WHERE SNo = :Id`,
            {
                replacements: { Id: id },
                type:         QueryTypes.SELECT,
            }
        );

        return records.length > 0 ? dataFound(res, [records[0]]) : noData(res);

    } catch (error) {
        console.error('Error in getDefaultLeaveById:', error);
        return servError(error, res);
    }
};

// ─── Private helpers ──────────────────────────────────────────────────────────

const getSingleEmployeeAttendance = async (
    db:       import('sequelize').Sequelize,
    FromDate: string,
    ToDate:   string,
    EmpId:    string,
): Promise<AttendanceResult[]> => {

    const query = `
        WITH Numbers AS (
            SELECT 0 AS n
            UNION ALL
            SELECT n + 1 FROM Numbers WHERE n < DATEDIFF(day, CAST(:FromDate AS DATE), CAST(:ToDate AS DATE))
        ),
        RankedLogs AS (
            SELECT
                em.User_Mgt_Id,
                COALESCE(u.Name, '') AS username,
                COALESCE(u.UDel_Flag, 0) AS UDel_Flag,
                em.fingerPrintEmpId,
                em.Sex AS Sex,
                al.AttendanceDate AS LogDateTime,
                CAST(al.AttendanceDate AS DATE) AS LogDate,
                ROW_NUMBER() OVER (
                    PARTITION BY em.User_Mgt_Id, CAST(al.AttendanceDate AS DATE)
                    ORDER BY al.AttendanceDate
                ) AS rn,
                COUNT(*) OVER (
                    PARTITION BY em.User_Mgt_Id, CAST(al.AttendanceDate AS DATE)
                ) AS record_count
            FROM tbl_Employee_Master em
            LEFT JOIN tbl_Users u
                ON u.Global_User_ID = em.User_Mgt_Id
            LEFT JOIN etimetracklite1.dbo.Employees pd
                ON CAST(pd.EmployeeCode COLLATE DATABASE_DEFAULT AS NVARCHAR(50)) = em.fingerPrintEmpId COLLATE DATABASE_DEFAULT
            LEFT JOIN etimetracklite1.dbo.AttendanceLogs al
                ON al.EmployeeId = pd.EmployeeId
            WHERE
                COALESCE(u.UDel_Flag, 0) = 0
                AND al.status != 'Resigned'
                AND al.AttendanceDate >= CAST(:FromDate AS DATETIME)
                AND al.AttendanceDate < CAST(:ToDate AS DATETIME)
                AND em.User_Mgt_Id = :EmpCode
        ),
        DefaultLeaves AS (
            SELECT CAST(Date AS DATE) AS DefaultLeaveDate
            FROM tbl_Default_Leave
            WHERE Date >= CAST(:FromDate AS DATE)
              AND Date <  CAST(:ToDate   AS DATE)
        ),
        PunchDetails AS (
            SELECT
                em.User_Mgt_Id,
                CAST(al.AttendanceDate AS DATE) AS LogDate,
                COALESCE(
                    STRING_AGG(SUBSTRING(al.PunchRecords, 1, 5000), ', '),
                    '[]'
                ) AS PunchDateTimes
            FROM tbl_Employee_Master em
            LEFT JOIN etimetracklite1.dbo.Employees pd
                ON CAST(pd.EmployeeCode COLLATE DATABASE_DEFAULT AS NVARCHAR(50)) = em.fingerPrintEmpId COLLATE DATABASE_DEFAULT
            LEFT JOIN etimetracklite1.dbo.AttendanceLogs al
                ON al.EmployeeId = pd.EmployeeId
            WHERE
                al.status != 'Resigned'
                AND ISNULL(CAST(al.PunchRecords AS NVARCHAR(MAX)), '') <> ''
                AND al.AttendanceDate >= CAST(:FromDate AS DATETIME)
                AND al.AttendanceDate < CAST(:ToDate AS DATETIME)
                AND em.User_Mgt_Id = :EmpCode
            GROUP BY em.User_Mgt_Id, CAST(al.AttendanceDate AS DATE)
        ),
        LeaveDays AS (
            SELECT
                lm.User_Id,
                DATEADD(DAY, n.n, CAST(lm.FromDate AS DATE)) AS LeaveDate
            FROM tbl_Leave_Master lm
            CROSS JOIN Numbers n
            WHERE
                lm.Status = 'Approved'
                AND DATEADD(DAY, n.n, CAST(lm.FromDate AS DATE)) <= CAST(lm.ToDate AS DATE)
        )
        SELECT
            e.User_Mgt_Id                       AS fingerPrintEmpId,
            COALESCE(d.Designation, 'NOT FOUND') AS Designation_Name,
            COALESCE(rl.username, '')            AS username,
            rl.Sex                               AS Sex,
            rl.LogDate,
            COALESCE(ag.PunchDateTimes, '[]')    AS AttendanceDetails,
            COALESCE(MAX(rl.record_count), 0)    AS TotalRecords,
            CASE
                WHEN DATEPART(WEEKDAY, rl.LogDate) = 1 THEN 'H'
                WHEN EXISTS (
                    SELECT 1 FROM LeaveDays ld
                    WHERE ld.User_Id = e.User_Mgt_Id AND ld.LeaveDate = rl.LogDate
                ) THEN 'L'
                WHEN EXISTS (
                    SELECT 1 FROM DefaultLeaves dl
                    WHERE dl.DefaultLeaveDate = rl.LogDate
                ) THEN 'DL'
                WHEN COALESCE(ag.PunchDateTimes, '') <> '' THEN 'P'
                ELSE 'A'
            END AS AttendanceStatus
        FROM tbl_Employee_Master e
        LEFT JOIN tbl_Employee_Designation d  ON e.Designation    = d.Designation_Id
        LEFT JOIN tbl_Users                u  ON e.User_Mgt_Id    = u.Global_User_ID
        LEFT JOIN RankedLogs               rl ON e.User_Mgt_Id    = rl.User_Mgt_Id
        LEFT JOIN PunchDetails             ag ON ag.User_Mgt_Id   = rl.User_Mgt_Id
                                             AND ag.LogDate        = rl.LogDate
        WHERE
            rl.LogDate IS NOT NULL
            AND rl.LogDate >= CAST(:FromDate AS DATETIME)
            AND rl.LogDate <  CAST(:ToDate   AS DATETIME)
            AND e.User_Mgt_Id = :EmpCode
            AND COALESCE(u.UDel_Flag, 0) = 0
        GROUP BY
            e.User_Mgt_Id, d.Designation, rl.username, rl.Sex, rl.LogDate, ag.PunchDateTimes
        ORDER BY rl.LogDate DESC
        OPTION (MAXRECURSION 1000)
    `;

    return db.query<AttendanceResult>(query, {
        replacements: { FromDate, ToDate, EmpCode: EmpId },
        type:         QueryTypes.SELECT,
    });
};

const getMultipleEmployeesAttendance = async (
    db:            import('sequelize').Sequelize,
    FromDate:      string,
    ToDate:        string,
    FingerPrintId?: string,
    UserMgtId?:    number | string,
): Promise<AttendanceResult[]> => {

    let filterCondition = '';
    let punchFilterCondition = '';

    if (FingerPrintId && FingerPrintId !== 'ALL' && FingerPrintId !== '0') {
        filterCondition = "AND em.fingerPrintEmpId = :FingerPrintId";
        punchFilterCondition = "AND pd.EmployeeCode = :FingerPrintId";
    } else if (UserMgtId) {
        filterCondition = "AND em.User_Mgt_Id = :UserMgtId";
        punchFilterCondition = "AND pd.EmployeeCode IN (SELECT fingerPrintEmpId COLLATE DATABASE_DEFAULT FROM tbl_Employee_Master WHERE User_Mgt_Id = :UserMgtId)";
    }

    const query = `
        WITH Numbers AS (
            SELECT 0 AS n
            UNION ALL
            SELECT n + 1 FROM Numbers WHERE n < DATEDIFF(day, CAST(:FromDate AS DATE), CAST(:ToDate AS DATE))
        ),
        RankedLogs AS (
                SELECT
                     em.fingerPrintEmpId,
                     em.User_Mgt_Id,
                     em.Emp_Name AS username,
                     em.Sex AS Sex,
                     pd.EmployeeCode,
                    pd.EmployeeId,
                   al.AttendanceDate AS LogDateTime,
                    CAST(al.AttendanceDate AS DATE) AS LogDate,
                   ROW_NUMBER() OVER (
                         PARTITION BY em.fingerPrintEmpId, CAST(al.AttendanceDate AS DATE)
                        ORDER BY al.AttendanceDate
                    ) AS rn,
                    COUNT(*) OVER (
                         PARTITION BY em.fingerPrintEmpId, CAST(al.AttendanceDate AS DATE)
                    ) AS record_count
                 FROM tbl_Employee_Master em
                 LEFT JOIN etimetracklite1.dbo.Employees pd
                    ON CAST(pd.EmployeeCode COLLATE DATABASE_DEFAULT AS NVARCHAR(50) ) = em.fingerPrintEmpId COLLATE DATABASE_DEFAULT
                LEFT JOIN etimetracklite1.dbo.AttendanceLogs al
                     ON al.EmployeeId = pd.EmployeeId
                 WHERE
                     al.status != 'Resigned'
                     AND al.AttendanceDate >= CAST(:FromDate AS DATETIME)
                     AND al.AttendanceDate < CAST(:ToDate AS DATETIME)
                     ${filterCondition}
            ),
        DefaultLeaves AS (
            SELECT CAST(Date AS DATE) AS DefaultLeaveDate
            FROM tbl_Default_Leave
            WHERE Date >= CAST(:FromDate AS DATE)
              AND Date <  CAST(:ToDate   AS DATE)
        ),
        PunchDetails AS (
            SELECT
                pd.EmployeeCode,
                CAST(al.AttendanceDate AS DATE) AS LogDate,
                COALESCE(
                    STRING_AGG(SUBSTRING(al.PunchRecords, 1, 5000), ', '),
                    '[]'
                ) AS PunchDateTimes
            FROM etimetracklite1.dbo.Employees pd
            LEFT JOIN etimetracklite1.dbo.AttendanceLogs al
                ON al.EmployeeId = pd.EmployeeId
            WHERE
                al.status != 'Resigned'
                AND ISNULL(CAST(al.PunchRecords AS NVARCHAR(MAX)), '') <> ''
                AND al.AttendanceDate >= CAST(:FromDate AS DATETIME)
                AND al.AttendanceDate < CAST(:ToDate AS DATETIME)
                ${punchFilterCondition}
            GROUP BY pd.EmployeeCode, CAST(al.AttendanceDate AS DATE)
        ),
        LeaveDays AS (
            SELECT
                lm.User_Id,
                DATEADD(DAY, n.n, CAST(lm.FromDate AS DATE)) AS LeaveDate
            FROM tbl_Leave_Master lm
            CROSS JOIN Numbers n
            WHERE
                lm.Status = 'Approved'
                AND DATEADD(DAY, n.n, CAST(lm.FromDate AS DATE)) <= CAST(lm.ToDate AS DATE)
        )
        SELECT
            em.fingerPrintEmpId,
            COALESCE(d.Designation, 'NOT FOUND')  AS Designation_Name,
            COALESCE(rl.username, '')              AS username,
            rl.Sex                                 AS Sex,
            rl.LogDate,
            COALESCE(ag.PunchDateTimes, '[]')      AS AttendanceDetails,
            COALESCE(MAX(rl.record_count), 0)      AS TotalRecords,
            CASE
                WHEN DATEPART(WEEKDAY, rl.LogDate) = 1 THEN 'H'
                WHEN EXISTS (
                    SELECT 1 FROM LeaveDays ld
                    WHERE ld.User_Id = rl.User_Mgt_Id AND ld.LeaveDate = rl.LogDate
                ) THEN 'L'
                WHEN EXISTS (
                    SELECT 1 FROM DefaultLeaves dl
                    WHERE dl.DefaultLeaveDate = rl.LogDate
                ) THEN 'DL'
                WHEN COALESCE(ag.PunchDateTimes, '') <> '' THEN 'P'
                ELSE 'A'
            END AS AttendanceStatus
        FROM tbl_Employee_Master em
        LEFT JOIN tbl_Employee_Designation d  ON em.Designation      = d.Designation_Id
        LEFT JOIN RankedLogs               rl ON em.fingerPrintEmpId  = rl.fingerPrintEmpId AND em.User_Mgt_Id = rl.User_Mgt_Id
        LEFT JOIN PunchDetails             ag ON ag.EmployeeCode      = rl.EmployeeCode
                                             AND ag.LogDate            = rl.LogDate
        WHERE
            rl.LogDate IS NOT NULL
            AND rl.LogDate >= CAST(:FromDate AS DATETIME)
            AND rl.LogDate <  CAST(:ToDate   AS DATETIME)
        GROUP BY
            em.fingerPrintEmpId, d.Designation, rl.username, rl.Sex,
            rl.LogDate, ag.PunchDateTimes, rl.User_Mgt_Id
        ORDER BY rl.LogDate DESC
        OPTION (MAXRECURSION 1000)
    `;

    const replacements: Record<string, unknown> = { FromDate, ToDate };
    if (FingerPrintId && FingerPrintId !== 'ALL' && FingerPrintId !== '0') {
        replacements.FingerPrintId = FingerPrintId;
    }
    if (UserMgtId) {
        replacements.UserMgtId = UserMgtId;
    }

    return db.query<AttendanceResult>(query, {
        replacements,
        type: QueryTypes.SELECT,
    });
};

export const attendanceSync = async (req: Request, res: Response) => {
    try {
        const { startDate, endDate } = req.body;

        if (!startDate || !endDate) {
            return res.status(400).json({
                error: "startDate and endDate are required"
            });
        }

        const db = req.companyDB;
        if (!db) {
            return res.status(500).json({ error: "Company database connection not found" });
        }

        try {
            await db.query("EXEC Online_Attendnace_Employee_SP");
        } catch (err: any) {
            // SQL Server Error 2571: User does not have permission to run DBCC DROPCLEANBUFFERS.
            // We ignore this error because it's a server-level cache clear that doesn't affect the data sync.
            if (err.parent && err.parent.number === 2571) {
                console.warn("Ignored DBCC DROPCLEANBUFFERS permission error.");
            } else {
                throw err;
            }
        }

        await db.query(
            "EXEC Online_AttendanceLogs_SP @Start_Date = :startDate, @To_Date = :endDate",
            {
                replacements: { startDate, endDate }
            }
        );

        (dataFound as any)(res, [], "Attendance sync completed successfully", {
            startDate,
            endDate
        });

    } catch (e) {
        servError(e, res);
    }
};

// ─── Default export ───────────────────────────────────────────────────────────

export default {
    attendanceSync,
    getFingerprintAttendance,
    getTodayAttendance,
    getEmployeeAttendanceSummary,
    getEmployeeAttendance,
    getDeviceAttendance,
    getAttendanceByDateRange,
    getMonthlyAttendance,
    getAbsentEmployees,
    getPresentEmployees,
    getAttendanceStats,
    getAllDefaultLeaves,
    getDefaultLeavesByDateRange,
    getDefaultLeaveById,
};